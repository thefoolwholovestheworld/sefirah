-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

return {
    name        = "Sefirah",
    fullname    = "Sefirah",
    description = "Suivi de web novels et export EPUB — fork de Mythos (unitreign)",
}
