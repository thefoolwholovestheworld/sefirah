-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- Réglages Sefirah. Version sans dépôt distant et sans JavaScript.
local LuaSettings = require("luasettings")
local DataStorage = require("datastorage")

local DEFAULTS = {
    covers_library  = true,
    covers_browse   = true,
    covers_detail   = true,
    extension_settings = {},
    chapters_ascending = false,
    -- Masquage global des commentaires/avis (bascule par appui long sur
    -- l'icône commentaire de l'onglet Chapitres, cf. ui/detail.lua) :
    -- true = onglet « Avis » caché, bulles de commentaires du lecteur
    -- retirées, section « Commentaires » de fin de chapitre masquée.
    comments_hidden = false,
    -- Filtre de langues des onglets Parcourir / Sources : liste de codes
    -- (ex. { "fr", "en" }). Liste vide = toutes les langues.
    lang_filter = {},
    -- Téléchargement des commentaires paragraphe par paragraphe avec chaque
    -- chapitre (consultables hors ligne). Beaucoup plus lent : désactivé par défaut.
    offline_comments = false,
}

local Settings = {}
local _file = nil

local function get_file()
    if not _file then
        local dir      = DataStorage:getSettingsDir()
        local new_path = dir .. "/sefirah.lua"
        local old_path = dir .. "/lnreader.lua"
        -- Reprise unique de l'ancien fichier de réglages (avant le renommage).
        local lfs = require("libs/libkoreader-lfs")
        if lfs.attributes(new_path, "mode") ~= "file" and lfs.attributes(old_path, "mode") == "file" then
            os.rename(old_path, new_path)
        end
        _file = LuaSettings:open(new_path)
    end
    return _file
end

function Settings:get(key)
    local val = get_file():readSetting(key)
    if val == nil then return DEFAULTS[key] end
    return val
end

function Settings:set(key, value)
    get_file():saveSetting(key, value)
    get_file():flush()
end

function Settings:toggle(key)
    self:set(key, not self:get(key))
end

function Settings:getExt(ext_id, key, default)
    local all = self:get("extension_settings") or {}
    local ext = all[ext_id] or {}
    local val = ext[key]
    if val == nil then return default end
    return val
end

function Settings:setExt(ext_id, key, value)
    local all = self:get("extension_settings") or {}
    if not all[ext_id] then all[ext_id] = {} end
    all[ext_id][key] = value
    self:set("extension_settings", all)
end

function Settings:toggleExt(ext_id, key, default)
    self:setExt(ext_id, key, not self:getExt(ext_id, key, default))
end

return Settings
