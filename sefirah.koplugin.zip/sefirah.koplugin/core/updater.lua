-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- core/updater.lua — Sefirah manual OTA updater
-- Checks GitHub releases API, downloads sefirah.koplugin.zip, unzips in-place,
-- deletes the zip, then offers a KOReader restart.

local UIManager   = require("ui/uimanager")
local InfoMessage = require("ui/widget/infomessage")
local ConfirmBox  = require("ui/widget/confirmbox")
local DataStorage = require("datastorage")
local logger      = require("logger")

local Updater = {}

-- Source des mises à jour : releases du dépôt GitHub ci-dessous.
-- Si GITHUB_OWNER est vide, la vérification de mise à jour est désactivée.
local GITHUB_OWNER = "thefoolwholovestheworld"
local GITHUB_REPO  = "sefirah"
local ASSET_NAME   = "sefirah.koplugin.zip"
local API_URL      = (GITHUB_OWNER ~= "")
    and ("https://api.github.com/repos/" .. GITHUB_OWNER .. "/" .. GITHUB_REPO .. "/releases/latest")
    or nil

-- core/ directory (where this file lives)
local _core_dir   = (debug.getinfo(1, "S").source or ""):match("^@?(.+)/[^/]+%.lua$") or ""
-- sefirah.koplugin/ — one level up from core/
local _plugin_dir = _core_dir:match("^(.+)/[^/]+$") or _core_dir
-- plugins/ directory — one level up from sefirah.koplugin/; zip extracts here
local _parent_dir = _plugin_dir:match("^(.+)/[^/]+$") or _plugin_dir

-- ── Version helpers ───────────────────────────────────────────────────────────

local function current_version()
    return _G.SEFIRAH_VERSION or "0.0.0"
end

-- Returns true if semver string a is strictly greater than b.
-- Strips "v" prefix and pre-release suffixes before comparing.
local function version_gt(a, b)
    local function parts(v)
        v = (v or ""):match("^v?(.-)[-+]") or (v or ""):match("^v?(.+)$") or ""
        local t = {}
        for n in (v .. "."):gmatch("(%d+)%.") do t[#t + 1] = tonumber(n) or 0 end
        while #t < 3 do t[#t + 1] = 0 end
        return t
    end
    local pa, pb = parts(a), parts(b)
    for i = 1, 3 do
        if pa[i] > pb[i] then return true end
        if pa[i] < pb[i] then return false end
    end
    return false
end

-- ── HTTP ──────────────────────────────────────────────────────────────────────

-- IMPORTANT : ssl.https (LuaSec) refuse l'option `redirect` ("redirect not
-- supported"). On ne la passe donc JAMAIS et on suit les redirections à la main
-- (301/302/303/307/308, 5 maximum) en relisant l'en-tête Location.
local function _request(url, sink, extra_headers)
    local https = require("ssl.https")
    local http  = require("socket.http")
    local req   = url:match("^https") and https or http
    local headers = { ["User-Agent"] = "KOReader-Sefirah-Updater" }
    if extra_headers then
        for k, v in pairs(extra_headers) do headers[k] = v end
    end
    local ok, code, resp_headers = req.request{
        url     = url,
        sink    = sink,
        headers = headers,
        timeout = 20,
        -- false (et non nil) : LuaSocket ne suit rien, c'est la boucle
        -- ci-dessous qui gère les redirections. `false` est accepté par LuaSec
        -- (seule une valeur vraie déclenche « redirect not supported »).
        redirect = false,
    }
    return ok, code, resp_headers
end

local function is_redirect(code)
    return code == 301 or code == 302 or code == 303 or code == 307 or code == 308
end

local function absolute_location(base, loc)
    if loc:match("^https?://") then return loc end
    local origin = base:match("^(https?://[^/]+)")
    if loc:sub(1, 1) == "/" then return origin .. loc end
    return origin .. "/" .. loc
end

-- GET texte (API JSON) avec redirections manuelles.
local function http_get(url)
    local ltn12 = require("ltn12")
    local cur = url
    for _ = 1, 6 do
        local sink = {}
        local ok, code, rh = _request(cur, ltn12.sink.table(sink), {
            ["Accept"] = "application/vnd.github.v3+json",
        })
        logger.dbg("Sefirah/Updater: GET", cur, "→", tostring(code))
        if ok and code == 200 then return table.concat(sink) end
        if ok and is_redirect(code) then
            local loc = rh and (rh["location"] or rh["Location"])
            if not loc then return nil, "redirect with no Location header" end
            cur = absolute_location(cur, loc)
        else
            return nil, tostring(code)
        end
    end
    return nil, "too many redirects"
end

-- Téléchargement vers un fichier (asset GitHub -> redirection vers le CDN).
local function http_download(url, dest)
    local ltn12 = require("ltn12")
    local cur = url
    for _ = 1, 6 do
        local fh, err = io.open(dest, "wb")
        if not fh then return nil, "cannot open dest: " .. tostring(err) end
        -- Le sink fichier est fermé par ltn12 ; sur une redirection, le corps
        -- (vide ou minuscule) est simplement réécrit à l'essai suivant.
        local ok, code, rh = _request(cur, ltn12.sink.file(fh), nil)
        logger.dbg("Sefirah/Updater: download", cur, "→", tostring(code))
        if ok and code == 200 then return true end
        if ok and is_redirect(code) then
            local loc = rh and (rh["location"] or rh["Location"])
            if not loc then pcall(os.remove, dest); return nil, "redirect with no Location header" end
            cur = absolute_location(cur, loc)
        else
            pcall(os.remove, dest)
            return nil, tostring(code)
        end
    end
    pcall(os.remove, dest)
    return nil, "too many redirects"
end

-- GitHub/CDN renvoie parfois un 5xx passager (503…) : on réessaie jusqu'à 3 fois.
local function http_download_retry(url, dest)
    local ok, err
    for attempt = 1, 3 do
        ok, err = http_download(url, dest)
        if ok then return true end
        if not tostring(err):match("^5%d%d$") then break end
        logger.warn("Sefirah/Updater: serveur indisponible (", tostring(err), "), essai", attempt, "/ 3")
        if attempt < 3 then require("socket").sleep(2) end
    end
    return nil, err
end

-- ── Release parsing ───────────────────────────────────────────────────────────

local function parse_release(body)
    local ok_j, JSON = pcall(require, "rapidjson")
    if not ok_j then ok_j, JSON = pcall(require, "json") end

    if ok_j then
        local ok_d, data = pcall(JSON.decode, body)
        if not ok_d or type(data) ~= "table" then return nil, "JSON parse error" end
        local tag = data.tag_name
        if not tag then return nil, "missing tag_name" end

        local dl_url
        for _, asset in ipairs(data.assets or {}) do
            if asset.name == ASSET_NAME then
                dl_url = asset.browser_download_url
                break
            end
        end

        local notes
        local raw = data.body or ""
        local block = raw:match("<!%-%-hisefirah%-%->(.-)<!%-%-/hisefirah%-%->")
        if block and block:match("%S") then
            notes = block:gsub("\r\n", "\n"):gsub("\r", "\n"):match("^%s*(.-)%s*$")
        end

        return {
            version      = tag:match("v?(.*)"),
            download_url = dl_url,
            notes        = (notes and notes ~= "") and notes or nil,
        }
    end

    -- json module unavailable — regex fallback
    logger.warn("Sefirah/Updater: json unavailable, using regex fallback")
    local tag = body:match('"tag_name"%s*:%s*"([^"]*)"')
    if not tag then return nil, "could not parse tag_name" end
    local asset_pat = '"browser_download_url"%s*:%s*"([^"]*'
        .. ASSET_NAME:gsub("%.", "%%.") .. '[^"]*)"'
    local raw_body = body:match('"body"%s*:%s*"(.-[^\\])"') or ""
    raw_body = raw_body:gsub("\\n", "\n"):gsub("\\r", ""):gsub('\\"', '"')
    local fb_notes
    local fb_block = raw_body:match("<!%-%-hisefirah%-%->(.-)<!%-%-/hisefirah%-%->")
    if fb_block and fb_block:match("%S") then
        fb_notes = fb_block:match("^%s*(.-)%s*$")
    end
    return {
        version      = tag:match("v?(.*)"),
        download_url = body:match(asset_pat),
        notes        = fb_notes,
    }
end

-- ── Temp zip path ─────────────────────────────────────────────────────────────

local function tmp_zip_path()
    local candidates = {
        DataStorage:getSettingsDir() .. "/sefirah_update.zip",
        "/tmp/sefirah_update.zip",
        _plugin_dir .. "/sefirah_update.zip",
    }
    for _, path in ipairs(candidates) do
        local fh = io.open(path, "wb")
        if fh then fh:close(); os.remove(path); return path end
    end
    return _plugin_dir .. "/sefirah_update.zip"
end

-- ── Install ───────────────────────────────────────────────────────────────────

local function apply_update(download_url, new_version)
    local zip = tmp_zip_path()

    local progress = InfoMessage:new{
        text    = "Downloading Sefirah v" .. new_version .. "…",
        timeout = 120,
    }
    UIManager:show(progress)

    UIManager:scheduleIn(0.3, function()
        local dl_ok, dl_err = http_download_retry(download_url, zip)
        UIManager:close(progress)

        if not dl_ok then
            logger.err("Sefirah/Updater: download failed:", dl_err)
            UIManager:show(InfoMessage:new{
                text    = "Download failed: " .. tostring(dl_err),
                timeout = 5,
            })
            return
        end

        logger.dbg("Sefirah/Updater: unzipping", zip, "→", _parent_dir)
        local ret = os.execute(
            string.format("unzip -o -q %q -d %q", zip, _parent_dir)
        )
        os.remove(zip)

        if ret ~= 0 and ret ~= true then
            logger.err("Sefirah/Updater: unzip failed, exit=", tostring(ret))
            UIManager:show(InfoMessage:new{
                text    = "Extraction failed. Please update manually.",
                timeout = 5,
            })
            return
        end

        logger.info("Sefirah/Updater: update to", new_version, "installed")
        UIManager:show(ConfirmBox:new{
            text        = "Sefirah v" .. new_version
                       .. " installed.\n\nRestart KOReader to apply the update?",
            ok_text     = "Restart now",
            cancel_text = "Later",
            ok_callback = function() UIManager:restartKOReader() end,
        })
    end)
end

-- ── Public API ────────────────────────────────────────────────────────────────

function Updater.checkForUpdates()
    if not API_URL then
        UIManager:show(InfoMessage:new{
            text    = "Aucune source de mise à jour configurée.",
            timeout = 4,
        })
        return
    end
    local NetworkMgr = require("ui/network/manager")
    NetworkMgr:runWhenOnline(function()
        local checking = InfoMessage:new{ text = "Checking for updates…", timeout = 15 }
        UIManager:show(checking)

        UIManager:scheduleIn(0.3, function()
            local body, fetch_err = http_get(API_URL)
            UIManager:close(checking)

            if not body then
                logger.err("Sefirah/Updater: fetch failed:", fetch_err)
                UIManager:show(InfoMessage:new{
                    text    = "Could not reach GitHub (Sefirah v" .. current_version() .. "): " .. tostring(fetch_err),
                    timeout = 4,
                })
                return
            end

            local release, parse_err = parse_release(body)
            if not release then
                logger.err("Sefirah/Updater: parse failed:", parse_err)
                UIManager:show(InfoMessage:new{
                    text    = "Could not read release info.",
                    timeout = 4,
                })
                return
            end

            local current = current_version()
            logger.info("Sefirah/Updater: current=", current, "latest=", release.version)

            if not version_gt(release.version, current) then
                UIManager:show(InfoMessage:new{
                    text    = "Sefirah is up to date (v" .. current .. ").",
                    timeout = 3,
                })
                return
            end

            if not release.download_url then
                UIManager:show(InfoMessage:new{
                    text    = "Sefirah v" .. release.version
                           .. " is available but has no download file yet.",
                    timeout = 5,
                })
                return
            end

            local header = "Sefirah v" .. release.version .. " is available!\n"
                        .. "You have v" .. current .. "."
            local notes  = release.notes
                        and ("\n\nWhat's new:\n" .. release.notes)
                        or  ""

            UIManager:show(ConfirmBox:new{
                text        = header .. notes .. "\n\nDownload and install now?",
                ok_text     = "Install",
                cancel_text = "Cancel",
                ok_callback = function()
                    apply_update(release.download_url, release.version)
                end,
            })
        end)
    end)
end

return Updater
