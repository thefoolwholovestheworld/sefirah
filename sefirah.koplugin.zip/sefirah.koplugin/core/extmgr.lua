-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

local logger      = require("logger")
local ExtMgr = {}

-- Dossier du plugin (…/sefirah.koplugin) : les sources « maison » y sont livrées
-- dans extensions/, donc une simple installation du plugin suffit.
local _core_dir   = (debug.getinfo(1, "S").source or ""):match("^@?(.+)/[^/]+%.lua$") or ""
local _plugin_dir = _core_dir:match("^(.+)/[^/]+$") or _core_dir

-- Sources actives : sites "maison" (chacun un fichier .lua dans
-- extensions/, chargé via dofile à la demande).
--
-- WebNovel et AO3 retirées : WebNovel.com est protégé par un challenge
-- Cloudflare (JS) que des requêtes HTTP brutes en Lua ne peuvent pas
-- résoudre — pas de contournement possible sans moteur JS embarqué, qui
-- n'existe pas dans KOReader. AO3 retirée à la demande de l'utilisateur.
local metas = {
    { id = "novelfrance", name = "NovelFrance",          site = "https://novelfrance.fr",         lang = "fr",    version = "1.0.0", runtime = "lua" },
    { id = "novelfire",   name = "NovelFire",            site = "https://novelfire.net",          lang = "en",    version = "1.1.0", runtime = "lua" },
    { id = "royalroad",   name = "Royal Road",           site = "https://www.royalroad.com",      lang = "en",    version = "1.0.0", runtime = "lua" },
    { id = "skynovels",   name = "SkyNovels",            site = "https://www.skynovels.net",     lang = "es",    version = "1.0.0", runtime = "lua" },
    { id = "69shu",       name = "69书吧",                   site = "https://www.69shu.xyz",         lang = "zh",    version = "1.5.0", runtime = "lua" },
}

local loaded = {}

local function loadone(id)
    if loaded[id] then return loaded[id] end

    -- Extension livrée avec le plugin (extensions/<id>.lua).
    local ok, x = pcall(dofile, _plugin_dir .. "/extensions/" .. id .. ".lua")
    if ok and type(x) == "table" then
        loaded[id] = x
        return x
    end
    logger.err("Sefirah: impossible de charger l'extension", id, tostring(x))
    return nil
end

-- Chargement paresseux : chaque extension n'est compilée qu'à sa première
-- utilisation (ExtMgr.get), plus toutes d'un coup à l'ouverture de Sefirah.
function ExtMgr.init() end

local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
if not ok_lfs then lfs = require("lfs") end

-- Une source est disponible si son fichier existe — sans charger le fichier.
local function available(id)
    return lfs.attributes(_plugin_dir .. "/extensions/" .. id .. ".lua", "mode") == "file"
end

function ExtMgr.get(id)
    return loadone(id)
end

function ExtMgr.getMeta(id)
    for _, m in ipairs(metas) do
        if m.id == id then return m end
    end
    return nil
end

function ExtMgr.installed()
    local r = {}
    for _, m in ipairs(metas) do
        if available(m.id) then
            local x = {}
            for k, v in pairs(m) do x[k] = v end
            r[#r + 1] = x
        end
    end
    return r
end

-- ── Langues ───────────────────────────────────────────────────────────────────
local LANG_LABELS = {
    fr = "Français", en = "Anglais", es = "Espagnol", zh = "Chinois",
    pt = "Portugais", de = "Allemand", it = "Italien", ja = "Japonais",
    ko = "Coréen", ru = "Russe", id = "Indonésien", tr = "Turc", ar = "Arabe",
}

function ExtMgr.langCode(m)
    return ((m.lang or "en"):lower():match("^(%a+)")) or "en"
end

function ExtMgr.langLabel(code)
    return LANG_LABELS[code] or code:upper()
end

-- Langues présentes parmi les sources installées : { {code=, label=, count=}, ... }
function ExtMgr.languages()
    local counts, list = {}, {}
    for _, m in ipairs(ExtMgr.installed()) do
        local c = ExtMgr.langCode(m)
        if not counts[c] then
            counts[c] = { code = c, label = ExtMgr.langLabel(c), count = 0 }
            list[#list + 1] = counts[c]
        end
        counts[c].count = counts[c].count + 1
    end
    table.sort(list, function(a, b) return a.label < b.label end)
    return list
end

-- Codes de langue actuellement retenus par le filtre (ordre d'affichage),
-- limités aux langues qui existent encore. Liste vide = pas de filtre.
function ExtMgr.activeLangCodes()
    local sel = require("settings"):get("lang_filter")
    if type(sel) ~= "table" or #sel == 0 then return {} end
    local wanted = {}
    for _, c in ipairs(sel) do wanted[c] = true end
    local r = {}
    for _, l in ipairs(ExtMgr.languages()) do
        if wanted[l.code] then r[#r + 1] = l.code end
    end
    return r
end

-- Sources installées, filtrées par langue (toutes si aucun filtre actif).
function ExtMgr.visible()
    local all   = ExtMgr.installed()
    local codes = ExtMgr.activeLangCodes()
    if #codes == 0 then return all end
    local set = {}
    for _, c in ipairs(codes) do set[c] = true end
    local r = {}
    for _, m in ipairs(all) do
        if set[ExtMgr.langCode(m)] then r[#r + 1] = m end
    end
    return r
end

-- Suffixe de titre « · FR/EN » quand un filtre est actif, sinon "".
function ExtMgr.langTitleSuffix()
    local codes = ExtMgr.activeLangCodes()
    if #codes == 0 then return "" end
    local up = {}
    for i, c in ipairs(codes) do up[i] = c:upper() end
    return "  ·  " .. table.concat(up, "/")
end

function ExtMgr.install()      return false, "Sources natives intégrées" end
function ExtMgr.uninstall()    return false, "Sources natives intégrées" end
function ExtMgr.update()       return false, "Sources natives intégrées" end
function ExtMgr.refreshRepos() return false end
function ExtMgr.getRepos()     return {} end
function ExtMgr.addRepo()      return false end
function ExtMgr.removeRepo()   return false end

return ExtMgr
