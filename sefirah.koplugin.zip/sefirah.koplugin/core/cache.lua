-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- core/cache.lua — Cache de lecture hors-ligne + progression + téléchargement.
-- Réutilise le pattern de core/db.lua : un fichier résumé JSON (downloads.json)
-- + un fichier de contenu par chapitre sur disque.
local DataStorage = require("datastorage")
local logger      = require("logger")
local Avatars     = require("core.avatars")
local ok_lfs, lfs = pcall(require, "libs/libkoreader-lfs")
if not ok_lfs then lfs = require("lfs") end
local ok_json, JSON = pcall(require, "rapidjson")
if not ok_json then JSON = require("json") end

local Cache = {}

local base_dir     = DataStorage:getSettingsDir() .. "/sefirah"
local content_dir  = base_dir .. "/reader_cache"
local summary_path = base_dir .. "/downloads.json"

local _summary = nil  -- lazy: { novels = { [novel_key] = {...} } }

-- ── Internal ──────────────────────────────────────────────────────────────────

local function ensure_dirs()
    if lfs.attributes(base_dir, "mode") ~= "directory" then lfs.mkdir(base_dir) end
    if lfs.attributes(content_dir, "mode") ~= "directory" then lfs.mkdir(content_dir) end
end

local function novel_key(source_id, novel_path)
    return (source_id .. "__" .. novel_path):gsub("[^%w%-]", "_")
end

local function chapter_slug(chapter_path)
    return (chapter_path or ""):gsub("[^%w%-]", "_")
end

local function content_path(source_id, novel_path, chapter_path)
    return content_dir .. "/" .. novel_key(source_id, novel_path)
        .. "__" .. chapter_slug(chapter_path) .. ".html"
end

-- Fichier JSON séparé (un par chapitre) stockant le fil COMPLET des
-- commentaires de chaque paragraphe commenté — { [paragraph_id] = { {author,
-- content, ...}, ... }, ... }. Distinct de content_path (le HTML du
-- chapitre) : les commentaires peuvent être rafraîchis (nouveaux avis)
-- sans re-télécharger tout le chapitre, et vice-versa.
local function comments_path(source_id, novel_path, chapter_path)
    return content_dir .. "/" .. novel_key(source_id, novel_path)
        .. "__" .. chapter_slug(chapter_path) .. "__comments.json"
end

local function load_summary()
    if _summary then return _summary end
    ensure_dirs()
    local f = io.open(summary_path, "r")
    if not f then _summary = { novels = {} }; return _summary end
    local raw = f:read("*all"); f:close()
    local ok, parsed = pcall(JSON.decode, raw)
    _summary = (ok and parsed and parsed.novels) and parsed or { novels = {} }
    return _summary
end

local function save_summary()
    ensure_dirs()
    local f = io.open(summary_path, "w")
    if not f then logger.err("Sefirah/Cache: cannot write downloads.json"); return end
    f:write(JSON.encode(_summary))
    f:close()
end

-- create=true creates the entry (and its key) if it doesn't exist yet.
local function get_entry(source_id, novel_path, create)
    local data = load_summary()
    local key  = novel_key(source_id, novel_path)
    local e    = data.novels[key]
    if not e and create then
        e = {
            source_id  = source_id,
            novel_path = novel_path,
            chapters   = {},   -- [chapter_path] = { title, order, downloaded_at }
            progress   = nil,  -- dernier chapitre lu (compatibilité / reprise globale)
            progress_by_chapter = {}, -- [chapter_path] = { percent, updated_at }
            updated_at = os.time(),
        }
        data.novels[key] = e
    end
    return e
end

-- ── Query ─────────────────────────────────────────────────────────────────────

-- Identifiant stable d'un chapitre. Exporté (Cache.chapterKey) pour que TOUT
-- le code (detail.lua, readerview.lua, cache.lua) dérive la même clé à partir
-- du même chapitre : avant ce correctif, detail.lua utilisait un repli
-- différent (tostring(idx) au lieu de ""), ce qui pouvait faire pointer
-- l'affichage (coche téléchargé, progression) et le stockage disque vers
-- deux clés différentes pour un même chapitre sans `path`/`sourceUrl`.
-- On traite aussi une chaîne vide comme "absente" (Lua considère "" comme
-- vrai), pour ne pas regrouper par erreur plusieurs chapitres sous la clé "".
local function ch_key(ch)
    local p = ch.path
    if p == nil or p == "" then p = ch.sourceUrl end
    if p == nil or p == "" then p = nil end
    return p or ("idx:" .. tostring(ch.chapter_number or ch.order or ch.name or ch.title or "?"))
end
Cache.chapterKey = ch_key

function Cache.isChapterCached(source_id, novel_path, chapter_path)
    local e = get_entry(source_id, novel_path, false)
    if not e or not e.chapters[chapter_path] then return false end
    return lfs.attributes(content_path(source_id, novel_path, chapter_path), "mode") == "file"
end

function Cache.getChapterHtml(source_id, novel_path, chapter_path)
    local f = io.open(content_path(source_id, novel_path, chapter_path), "r")
    if not f then return nil end
    local html = f:read("*all"); f:close()
    return html
end

-- ── Commentaires par paragraphe (cache hors-ligne) ──────────────────────────
-- Remplis par cache_chapter_comments() plus bas (au moment du téléchargement
-- d'un chapitre) ET, en secours, par readerview.lua lui-même après chaque
-- consultation en ligne réussie d'un fil de paragraphe (Cache.mergeParagraphComments) —
-- pour que même un chapitre non explicitement "téléchargé" (juste lu en
-- ligne) garde ses commentaires déjà vus disponibles hors-ligne ensuite.

local function read_comments_file(source_id, novel_path, chapter_path)
    local f = io.open(comments_path(source_id, novel_path, chapter_path), "r")
    if not f then return {} end
    local raw = f:read("*all"); f:close()
    local ok, data = pcall(JSON.decode, raw)
    if not ok or type(data) ~= "table" then return {} end
    return data
end

local function write_comments_file(source_id, novel_path, chapter_path, by_paragraph)
    ensure_dirs()
    local ok_enc, encoded = pcall(JSON.encode, by_paragraph)
    if not ok_enc then return false end
    local f = io.open(comments_path(source_id, novel_path, chapter_path), "w")
    if not f then return false end
    f:write(encoded)
    f:close()
    return true
end

-- Renvoie le fil déjà en cache pour CE paragraphe, ou nil si absent (jamais
-- téléchargé/consulté, ou fichier de cache manquant/corrompu).
function Cache.getParagraphComments(source_id, novel_path, chapter_path, paragraph_id)
    local data = read_comments_file(source_id, novel_path, chapter_path)
    return data[paragraph_id]
end

-- Remplace en bloc TOUS les fils de commentaires d'un chapitre (utilisé au
-- téléchargement, où on récupère tout d'un coup) — by_paragraph :
-- { [paragraph_id] = { comments... }, ... }.
function Cache.storeAllParagraphComments(source_id, novel_path, chapter_path, by_paragraph)
    return write_comments_file(source_id, novel_path, chapter_path, by_paragraph)
end

-- Ajoute/remplace le fil d'UN SEUL paragraphe sans toucher aux autres déjà en
-- cache pour ce chapitre (lecture en ligne au fil de l'eau, cf. plus haut).
function Cache.mergeParagraphComments(source_id, novel_path, chapter_path, paragraph_id, comments)
    local data = read_comments_file(source_id, novel_path, chapter_path)
    data[paragraph_id] = comments
    return write_comments_file(source_id, novel_path, chapter_path, data)
end

function Cache.getNovelEntry(source_id, novel_path)
    return get_entry(source_id, novel_path, false)
end

function Cache.getDownloadedCount(source_id, novel_path)
    local e = get_entry(source_id, novel_path, false)
    if not e then return 0 end
    local n = 0
    for _ in pairs(e.chapters) do n = n + 1 end
    return n
end

-- Toutes les œuvres ayant au moins un chapitre en cache — alimente la
-- bibliothèque visuelle (couverture + titre + progression, tri par dernière activité).
function Cache.getAllDownloaded()
    local data = load_summary()
    local list = {}
    for _, e in pairs(data.novels) do
        local n = 0
        for _ in pairs(e.chapters) do n = n + 1 end
        if n > 0 then table.insert(list, e) end
    end
    table.sort(list, function(a, b) return (a.updated_at or 0) > (b.updated_at or 0) end)
    return list
end

-- ── Write ─────────────────────────────────────────────────────────────────────

-- Stocke un chapitre déjà récupéré (html brut renvoyé par ext:parseChapter).
function Cache.storeChapter(source_id, novel_path, chapter, html)
    ensure_dirs()
    local key = ch_key(chapter)
    local f = io.open(content_path(source_id, novel_path, key), "w")
    if not f then return false, "write_error" end
    f:write(html)
    f:close()

    local e = get_entry(source_id, novel_path, true)
    e.chapters[key] = {
        title         = chapter.name or chapter.title,
        order         = chapter.chapter_number,
        downloaded_at = os.time(),
    }
    e.updated_at = os.time()
    save_summary()
    return true
end

function Cache.removeChapter(source_id, novel_path, chapter_path)
    os.remove(content_path(source_id, novel_path, chapter_path))
    os.remove(comments_path(source_id, novel_path, chapter_path))
    local e = get_entry(source_id, novel_path, false)
    if e then
        e.chapters[chapter_path] = nil
        e.updated_at = os.time()
        save_summary()
    end
end

function Cache.removeNovel(source_id, novel_path)
    local e = get_entry(source_id, novel_path, false)
    if not e then return end
    for cp in pairs(e.chapters) do
        os.remove(content_path(source_id, novel_path, cp))
        os.remove(comments_path(source_id, novel_path, cp))
    end
    local data = load_summary()
    data.novels[novel_key(source_id, novel_path)] = nil
    save_summary()
end

-- ── Progression de lecture ────────────────────────────────────────────────────

function Cache.setProgress(source_id, novel_path, chapter_path, percent, current_page, total_pages, completed, charpos, top_line_num)
    local e = get_entry(source_id, novel_path, true)
    e.progress_by_chapter = e.progress_by_chapter or {}
    local old = e.progress_by_chapter[chapter_path] or {}
    local value = {
        chapter_path = chapter_path,
        percent      = math.max(0, math.min(1, tonumber(percent) or 0)),
        current_page = math.max(1, tonumber(current_page) or tonumber(old.current_page) or 1),
        total_pages  = math.max(1, tonumber(total_pages) or tonumber(old.total_pages) or 1),
        completed    = completed ~= nil and (completed and true or false) or (old.completed and true or false),
        charpos      = tonumber(charpos) or tonumber(old.charpos) or nil,
        top_line_num = tonumber(top_line_num) or tonumber(old.top_line_num) or nil,
        updated_at   = os.time(),
    }
    -- On garde aussi le dernier chapitre lu dans `progress` pour les anciennes
    -- versions et pour la reprise générale du roman. La table par chapitre
    -- permet surtout d'afficher la progression de CHAQUE chapitre.
    e.progress = value
    e.progress_by_chapter[chapter_path] = value
    e.updated_at = os.time()
    save_summary()
end

function Cache.getProgress(source_id, novel_path)
    local e = get_entry(source_id, novel_path, false)
    return e and e.progress or nil
end

function Cache.getChapterProgress(source_id, novel_path, chapter_path)
    local e = get_entry(source_id, novel_path, false)
    if not e then return nil end
    if e.progress_by_chapter and e.progress_by_chapter[chapter_path] then
        return e.progress_by_chapter[chapter_path]
    end
    -- Compatibilité avec les anciennes données : l'ancien format ne pouvait
    -- mémoriser qu'un seul chapitre.
    if e.progress and e.progress.chapter_path == chapter_path then
        return e.progress
    end
    return nil
end

-- ── Téléchargement réseau ─────────────────────────────────────────────────────
-- Réutilise exactement le même point d'entrée que core/epub.lua pour l'export
-- (ext:parseChapter), donc aucune extension existante n'a besoin d'être modifiée.

-- URL/identifiant source réellement transmis à l'extension pour récupérer un
-- chapitre. On rejette explicitement la chaîne vide : "" est truthy en Lua,
-- donc `chapter.path or chapter.sourceUrl` renvoyait "" (et jamais sourceUrl)
-- pour un chapitre mal formé dont `path` valait "", causant un échec de fetch
-- systématique sur ces chapitres-là.
local function ch_source_ref(chapter)
    local p = chapter.path
    if p == nil or p == "" then p = chapter.sourceUrl end
    if p == nil or p == "" then return nil end
    return p
end

-- Nombre de tentatives réseau avant d'abandonner un chapitre. Certains échecs
-- de téléchargement n'étaient dus qu'à un aléa réseau transitoire (timeout,
-- coupure Wi-Fi Kobo) : aucune tentative n'était rejouée auparavant, donc un
-- seul accroc suffisait à rendre un chapitre durablement "en échec".
local CHAPTER_FETCH_ATTEMPTS = 2

-- BUG CORRIGÉ (2026-09-12) : demandé — que les commentaires par paragraphe
-- soient disponibles HORS LIGNE pour les chapitres déjà téléchargés, sans
-- attendre d'être connecté au moment de taper sur chaque icône 💬. On
-- récupère donc ici, une fois le HTML du chapitre stocké, le fil COMPLET de
-- CHAQUE paragraphe commenté (`marks`, embarqué dans ce même HTML par
-- novelfrance.lua — cf. le trailer `<!--LNREADER_META:...-->`), et on les
-- range dans le cache séparé (Cache.storeAllParagraphComments ci-dessus).
-- `ext.parseParagraphComments` : n'existe que pour novelfrance.lua pour
-- l'instant — no-op silencieux pour toute autre source. pcall à chaque étape
-- (JSON, réseau) : un souci ici ne doit JAMAIS faire échouer le
-- téléchargement du chapitre lui-même, qui est déjà stocké avec succès à ce
-- stade — au pire, ce chapitre n'aura simplement pas ses commentaires en
-- cache (comme avant ce correctif), pas d'échec en cascade.
local function cache_chapter_comments(ext, source_id, novel_path, key, html)
    if not ext.parseParagraphComments then return end

    local ok_j, JSONc = pcall(require, "rapidjson")
    if not ok_j then JSONc = require("json") end

    local meta_json = html:match("<!%-%-LNREADER_META:(.-)%-%->")
    if not meta_json then return end
    local ok_dec, decoded = pcall(JSONc.decode, meta_json)
    if not ok_dec or type(decoded) ~= "table" or type(decoded.marks) ~= "table" or not decoded.chapterId then
        return
    end

    -- Plafonds : un chapitre populaire peut porter des centaines de paragraphes
    -- commentés, soit des centaines de requêtes réseau sérielles par chapitre.
    local MAX_MARKS, MAX_PAGES = 60, 5
    local by_paragraph = {}
    for mi, mark in ipairs(decoded.marks) do
        if mi > MAX_MARKS then break end
        if mark.id then
            local comments = {}
            local page, has_more, page_ok = 1, true, true
            while has_more and page <= MAX_PAGES do
                local ok_p, data = pcall(ext.parseParagraphComments, ext, decoded.chapterId, mark.id, page)
                if not ok_p then
                    page_ok = false
                    break
                end
                for _, c in ipairs((data and data.comments) or {}) do
                    table.insert(comments, c)
                end
                has_more = data and data.has_more or false
                page = page + 1
            end
            -- On ne stocke que si la récupération a réellement abouti (au
            -- moins une page sans erreur) — mieux vaut ne pas mettre ce
            -- paragraphe en cache que d'y écrire une liste tronquée par une
            -- panne réseau en cours de route, qui passerait ensuite pour
            -- "0 commentaire" alors qu'il en a.
            if page_ok then
                by_paragraph[mark.id] = comments
            end
        end
    end

    if next(by_paragraph) then
        pcall(Cache.storeAllParagraphComments, source_id, novel_path, key, by_paragraph)
    end

    -- pdp des commentaires de fin de chapitre (cf. chapterCommentMarks dans
    -- le trailer, ajouté par novelfrance.lua) : téléchargées et mises en
    -- cache disque ICI, dans le même contexte réseau que le reste de cette
    -- fonction (déjà appelée depuis Cache.downloadChapter, lui-même toujours
    -- dans un NetworkMgr:runWhenConnected côté appelant) — jamais au simple
    -- affichage d'un chapitre déjà en cache, pour ne jamais redéclencher de
    -- connexion Wi-Fi à l'improviste pendant la lecture hors-ligne.
    if type(decoded.chapterCommentMarks) == "table" and #decoded.chapterCommentMarks > 0 then
        local urls = {}
        for _, mark in ipairs(decoded.chapterCommentMarks) do
            if mark.avatar and mark.avatar ~= "" then
                table.insert(urls, mark.avatar)
            end
        end
        if #urls > 0 then
            pcall(Avatars.prefetch, urls)
        end
    end
end

-- `force` (optionnel) : si true, re-télécharge et écrase le cache même si le
-- chapitre est déjà présent, au lieu de renvoyer immédiatement on_done(true).
-- Sert à rafraîchir les avis/commentaires d'un chapitre déjà téléchargé,
-- qui sont embarqués dans le HTML renvoyé par ext:parseChapter — cf.
-- Detail.fetchForceRefresh (ui/detail.lua) qui appelle ceci avec force=true
-- pour tous les chapitres déjà en cache d'un roman quand on actualise ce
-- roman, afin de découvrir les nouveaux avis sans attendre que chaque
-- chapitre soit relu manuellement.
function Cache.downloadChapter(ext, source_id, novel_path, chapter, on_done, force)
    local key = ch_key(chapter)
    if not force and Cache.isChapterCached(source_id, novel_path, key) then
        return on_done(true)
    end
    local ref = ch_source_ref(chapter)
    if not ref then
        logger.warn("Sefirah/Cache: chapter has no path/sourceUrl, cannot fetch:", key)
        return on_done(false, "missing_chapter_reference")
    end

    local ok, html, parse_err, last_err
    for attempt = 1, CHAPTER_FETCH_ATTEMPTS do
        ok, html, parse_err = pcall(ext.parseChapter, ext, ref)
        if ok and html and html ~= "" then break end
        -- pcall renvoie (true, nil, "raison") quand parseChapter échoue
        -- proprement (return nil, "raison") plutôt que de lever une erreur :
        -- il faut donc regarder parse_err même si ok est vrai, sinon la
        -- vraie cause (ex. "chapter_content_not_found") est perdue et on
        -- affiche toujours le message générique "empty_response".
        last_err = (not ok) and html or (parse_err or "empty_response")
        logger.warn("Sefirah/Cache: fetch attempt", attempt, "failed for", key, ":", tostring(last_err))
    end
    if not ok or not html or html == "" then
        logger.warn("Sefirah/Cache: download failed for", key, "after", CHAPTER_FETCH_ATTEMPTS, "attempts:", tostring(last_err))
        return on_done(false, tostring(last_err))
    end
    local stored, err = Cache.storeChapter(source_id, novel_path, chapter, html)
    -- Commentaires hors ligne : désactivés par défaut (réglage « Commentaires
    -- hors ligne ») car ils multiplient le temps de téléchargement d'un chapitre.
    -- Sans eux, les commentaires restent consultables en ligne en tapant 💬.
    if stored then
        local ok_s, Settings = pcall(require, "settings")
        if ok_s and Settings:get("offline_comments") then
            pcall(cache_chapter_comments, ext, source_id, novel_path, key, html)
        end
    end
    on_done(stored, err)
end

-- File d'attente séquentielle (œuvre entière ou sélection).
-- Aucun délai artificiel entre deux chapitres : la requête réseau bloque déjà
-- naturellement jusqu'à sa fin. Cela accélère fortement les gros téléchargements.
-- `force` : voir Cache.downloadChapter ci-dessus.
function Cache.downloadChapters(ext, source_id, novel_path, chapters, on_progress, on_complete, force)
    local UIManager = require("ui/uimanager")
    local i = 0
    local function step()
        i = i + 1
        if i > #chapters then return on_complete() end
        Cache.downloadChapter(ext, source_id, novel_path, chapters[i], function(ok, err)
            if on_progress then on_progress(i, #chapters, ok, err) end
            -- Laisser UIManager reprendre la main, sans imposer 20 ms de pause.
            UIManager:scheduleIn(0, step)
        end, force)
    end
    step()
end

return Cache
