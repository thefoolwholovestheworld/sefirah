-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- Popup de réglages : active/désactive l'affichage des couvertures par écran.
-- Se rouvre après chaque bascule pour que les libellés des boutons restent à jour.
local UIManager        = require("ui/uimanager")
local ButtonDialogTitle = require("ui/widget/buttondialogtitle")
local Settings         = require("settings")

local SettingsDialog = {}
local _dlg = nil

local function on_off(key)
    return Settings:get(key) and "ACTIVÉ" or "DÉSACTIVÉ"
end

function SettingsDialog.show()
    if _dlg then UIManager:close(_dlg) end

    _dlg = ButtonDialogTitle:new{
        title   = "Réglages Sefirah",
        buttons = {
            {
                {
                    text     = "Couvertures · Page Bibliothèque : " .. on_off("covers_library"),
                    callback = function()
                        Settings:toggle("covers_library")
                        SettingsDialog.show()
                    end,
                },
            },
            {
                {
                    text     = "Couvertures · Page Parcourir : " .. on_off("covers_browse"),
                    callback = function()
                        Settings:toggle("covers_browse")
                        SettingsDialog.show()
                    end,
                },
            },
            {
                {
                    text     = "Couvertures · Page Détails : " .. on_off("covers_detail"),
                    callback = function()
                        Settings:toggle("covers_detail")
                        SettingsDialog.show()
                    end,
                },
            },
            {
                {
                    text     = "Commentaires hors ligne (plus lent) : " .. on_off("offline_comments"),
                    callback = function()
                        Settings:toggle("offline_comments")
                        SettingsDialog.show()
                    end,
                },
            },
            {
                {
                    text     = "Fermer",
                    callback = function()
                        UIManager:close(_dlg)
                        _dlg = nil
                    end,
                },
            },
        },
    }
    UIManager:show(_dlg)
end

return SettingsDialog
