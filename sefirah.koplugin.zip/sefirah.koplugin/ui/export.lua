-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- Dialogue d'export : choisir le mode, déclencher la génération EPUB.
local UIManager   = require("ui/uimanager")
local InputDialog = require("ui/widget/inputdialog")
local InfoMessage = require("ui/widget/infomessage")
local NetworkMgr  = require("ui/network/manager")
local DataStorage = require("datastorage")
local logger      = require("logger")
local Epub        = require("core.epub")
local DB          = require("core.db")
local ExtMgr      = require("core.extmgr")
local P           = require("ui.panel")

local Export = {}

local function close_all()
    if _G.sefirah_close_all then _G.sefirah_close_all() end
end

local function sefirah_base_dir()
    local home = G_reader_settings and G_reader_settings:readSetting("home_dir")
    if not home or home == "" then
        local full = DataStorage:getFullDataDir() or DataStorage:getDataDir()
        home = full:match("^(.*)/%.adds/") or full:match("^(.*)/koreader$") or full
    end
    local Settings = require("settings")
    if Settings:get("export_location_flat") then return home end
    return home .. "/Sefirah"
end

local MODES = {
    { id = "all_in_one",  label = "Tout en un seul EPUB",         desc = "Tous les chapitres → un seul fichier" },
    { id = "per_chapter", label = "Un EPUB par chapitre",    desc = "Chaque chapitre → fichier séparé"    },
    { id = "every_n",     label = "Regrouper tous les N chapitres", desc = "Regrouper en volumes"               },
    { id = "range",       label = "Choisir une plage de chapitres",  desc = "Du chapitre X au chapitre Y → un seul fichier"  },
}

local _ctx   = nil
local _mode  = "all_in_one"
local _n     = 50
local _range_start = nil
local _range_end   = nil
local _include_reviews = false
local _include_comments = false
local _panel = nil

local function rebuild(ctx)
    Export.show(ctx)
end

-- Retourne les chapitres dont le numéro est compris dans la plage demandée.
local function chapter_number_value(ch, fallback)
    if ch and ch.chapter_number ~= nil then
        local n = tonumber(tostring(ch.chapter_number):match("[%d%.]+"))
        if n then return n end
    end
    local name = ch and (ch.name or ch.title) or ""
    local n = tonumber(tostring(name):match("(%d+[%d%.]*)"))
    return n or fallback
end

local function chapters_in_range(chapters, first_num, last_num)
    first_num, last_num = tonumber(first_num), tonumber(last_num)
    if not first_num or not last_num then return {} end
    if first_num > last_num then first_num, last_num = last_num, first_num end
    local out = {}
    for _, ch in ipairs(chapters or {}) do
        local n = chapter_number_value(ch, nil)
        if n and n >= first_num and n <= last_num then out[#out + 1] = ch end
    end
    table.sort(out, function(a,b) return chapter_number_value(a, math.huge) < chapter_number_value(b, math.huge) end)
    return out
end

-- Trie toujours les chapitres dans l'ordre chronologique du novel
-- (1, 2, 3, ... 56), indépendamment de l'ordre reçu par la source/API.
local function sort_chapters_oldest_first(chapters)
    local out = {}
    for i, ch in ipairs(chapters or {}) do
        out[#out + 1] = { ch = ch, original_index = i }
    end

    table.sort(out, function(a, b)
        local na = chapter_number_value(a.ch, nil)
        local nb = chapter_number_value(b.ch, nil)

        -- Les chapitres numérotés passent avant ceux sans numéro.
        if na == nil and nb ~= nil then return false end
        if na ~= nil and nb == nil then return true end

        -- Tri numérique : 1, 2, 3, ... 10, 11, ... 56
        if na ~= nil and nb ~= nil and na ~= nb then
            return na < nb
        end

        -- Ordre stable pour les égalités / chapitres sans numéro.
        return a.original_index < b.original_index
    end)

    local sorted = {}
    for i, item in ipairs(out) do
        sorted[i] = item.ch
    end
    return sorted
end
-- ── Exécution ─────────────────────────────────────────────────────────────────

function Export.run(ctx)
    -- Ferme le panneau d'options d'export → le panneau détails redevient visible
    Export.close()

    local novel   = ctx.novel
    local title   = novel.name or novel.title or "Roman"
    local out_dir = sefirah_base_dir() .. "/" .. title:gsub('[<>:"/\\|?*]', "_")
    -- IMPORTANT : l'EPUB doit toujours aller du chapitre le plus ancien au plus récent.
    local chapters = sort_chapters_oldest_first(ctx.chapters or {})
    if _mode == "range" then
        chapters = chapters_in_range(chapters, _range_start, _range_end)
        if #chapters == 0 then
            UIManager:show(InfoMessage:new{ text = "Aucune plage valide à exporter.", timeout = 3 })
            return
        end
    end
    logger.dbg("Sefirah/Export: title=", title, "out_dir=", out_dir)

    -- Suit automatiquement le roman quand un export démarre
    DB.track({
        title          = title,
        source_id      = ctx.source_id,
        path           = novel.path or "",
        cover          = novel.cover,
        author         = novel.author,
        status         = novel.status,
        total_chapters = ctx.total_chapters or novel.total_chapters or #chapters,
    })

    -- Affiche l'indicateur ; scheduleIn cède la main pour qu'UIManager le peigne avant le travail bloquant
    local progress_msg = InfoMessage:new{ text = "Démarrage de l'export…" }
    UIManager:show(progress_msg)

    UIManager:scheduleIn(0.1, function()
        NetworkMgr:runWhenConnected(function()
            local options = {
                title     = title,
                author    = novel.author,
                language  = "fr",
                series    = title,
                n         = _n,
                out_dir   = out_dir,
                cover_url     = novel.cover,
                cover_referer = (ExtMgr.getMeta(ctx.source_id) or {}).site,
                summary       = novel.summary,
                include_reviews = _include_reviews,
                include_comments = _include_comments,
                reviews_fn = ctx.reviews_fn,
            }

            local last_repaint = os.time()
            local results = Epub.export(
                _mode, options, chapters, ctx.fetch_fn,
                function(done, total)
                    if done % 10 == 0 or done == total then
                        if progress_msg then UIManager:close(progress_msg) end
                        progress_msg = InfoMessage:new{
                            text    = string.format("Export %d / %d…", done, total),
                            timeout = 120,
                        }
                        UIManager:show(progress_msg)
                        -- Force un rafraîchissement d'écran au plus toutes les 10 s (le rafraîchissement e-ink est lent)
                        local now = os.time()
                        if now - last_repaint >= 10 then
                            last_repaint = now
                            pcall(function() UIManager:forceRePaint() end)
                        end
                    end
                end)

            if progress_msg then UIManager:close(progress_msg); progress_msg = nil end

            -- Enregistre les chapitres exportés dans la BD
            if #results.exported > 0 then
                local ch_paths = {}
                for _, ch in ipairs(chapters) do
                    ch_paths[#ch_paths + 1] = ch.path or ch.sourceUrl or ""
                end
                for _, epub_path in ipairs(results.exported) do
                    DB.recordExport(ctx.source_id, novel.path or "", ch_paths, epub_path)
                end
            end

            local n_ok  = #results.exported
            local n_err = #results.errors
            UIManager:show(InfoMessage:new{
                text = string.format(
                    "Export terminé.\n%d fichier%s enregistré(s) dans\n%s\n%s",
                    n_ok, n_ok == 1 and "" or "s", out_dir,
                    n_err > 0 and (tostring(n_err) .. " chapitre(s) en échec.") or ""),
                timeout = 6,
            })
        end)
    end)
end

-- ── Affichage ───────────────────────────────────────────────────────────────

function Export.show(ctx)
    local SefirahUI = require("ui.main_widget")
    if _ctx ~= ctx then
        _range_start, _range_end = nil, nil
        _mode = "all_in_one"
        _n = 50
        _include_reviews = false
        _include_comments = false
    end
    _ctx           = ctx
    local ch_cnt   = #(ctx.chapters or {})
    local Settings = require("settings")
    local flat     = Settings:get("export_location_flat")

    local rows = {}

    table.insert(rows, P.makeRow(
        string.format("%d chapitre%s disponible(s)", ch_cnt, ch_cnt == 1 and "" or "s"),
        { dim = true, callback = function() end }
    ))

    local locked_cnt = 0
    for _, ch in ipairs(ctx.chapters or {}) do
        if ch.locked then locked_cnt = locked_cnt + 1 end
    end
    if locked_cnt > 0 then
        table.insert(rows, P.makeRow(
            string.format("[!] %d chapitre%s verrouillé(s) dans la liste",
                locked_cnt, locked_cnt == 1 and "" or "s"),
            { bold = true, callback = function() end }
        ))
        table.insert(rows, P.makeRow(
            "Les chapitres verrouillés n'ont pas de contenu accessible et seront exportés en pages vides.",
            { dim = true, callback = function() end }
        ))
    end

    table.insert(rows, P.hairline())

    -- Sélection du mode
    for _, m in ipairs(MODES) do
        local mid = m.id
        table.insert(rows, P.makeRow(
            (mid == _mode and "> " or "  ") .. m.label, {
                mandatory = m.desc,
                bold      = mid == _mode,
                callback  = function() _mode = mid; rebuild(ctx) end,
            }
        ))
    end

    -- Sélecteur de N (uniquement quand every_n est actif)
    if _mode == "every_n" then
        table.insert(rows, P.makeRow(
            string.format("Chapitres par volume : %d  (appuyer pour changer)", _n), {
                callback = function()
                    local dlg
                    dlg = InputDialog:new{
                        title      = "Chapitres par volume",
                        input_type = "number",
                        input_hint = tostring(_n),
                        buttons    = {{
                            {
                                text             = "OK",
                                is_enter_default = true,
                                callback         = function()
                                    local v = tonumber(dlg:getInputText())
                                    if v and v > 0 then _n = math.floor(v) end
                                    UIManager:close(dlg)
                                    rebuild(ctx)
                                end,
                            },
                            { text = "Annuler", callback = function() UIManager:close(dlg) end },
                        }},
                    }
                    UIManager:show(dlg)
                end,
            }
        ))
    end

    if _mode == "range" then
        local range_label = (_range_start and _range_end)
            and string.format("Chapitres %g à %g", _range_start, _range_end)
            or "Choisir les chapitres à exporter"
        table.insert(rows, P.makeRow(range_label, {
            mandatory = "appuyer pour choisir",
            bold = true,
            callback = function()
                local first_dlg
                first_dlg = InputDialog:new{
                    title = "Premier chapitre", input_type = "number", input_hint = "Ex. 1629",
                    buttons = {{
                        { text = "Annuler", callback = function() UIManager:close(first_dlg) end },
                        { text = "Suivant", is_enter_default = true, callback = function()
                            local first = tonumber(first_dlg:getInputText())
                            if not first then return end
                            UIManager:close(first_dlg)
                            local last_dlg
                            last_dlg = InputDialog:new{
                                title = "Dernier chapitre", input_type = "number", input_hint = "Ex. 2003",
                                buttons = {{
                                    { text = "Annuler", callback = function() UIManager:close(last_dlg) end },
                                    { text = "Valider", is_enter_default = true, callback = function()
                                        local last = tonumber(last_dlg:getInputText())
                                        UIManager:close(last_dlg)
                                        if not last then return end
                                        local count = #chapters_in_range(ctx.chapters, first, last)
                                        if count == 0 then
                                            UIManager:show(InfoMessage:new{ text = "Aucun chapitre trouvé dans cette plage.", timeout = 3 })
                                            return
                                        end
                                        _range_start, _range_end = first, last
                                        rebuild(ctx)
                                    end },
                                }},
                            }
                            UIManager:show(last_dlg)
                        end },
                    }},
                }
                UIManager:show(first_dlg)
            end,
        }))
    end

    -- FIX : options "Avis des lecteurs au début du livre" et "Tous les
    -- commentaires dans les chapitres" retirées (demandé) — _include_reviews
    -- et _include_comments restent déclarées ci-dessus mais valent toujours
    -- false désormais, faute de case à cocher pour les activer.
    table.insert(rows, P.hairline())

    -- Bascule de l'emplacement
    table.insert(rows, P.makeRow(
        (not flat and "> " or "  ") .. "Home/Sefirah/Série/Livre.epub", {
            mandatory = "organisé",
            bold      = not flat,
            callback  = function()
                Settings:set("export_location_flat", false)
                rebuild(ctx)
            end,
        }
    ))
    table.insert(rows, P.makeRow(
        (flat and "> " or "  ") .. "Home/Série/Livre.epub", {
            mandatory = "plat",
            bold      = flat == true,
            callback  = function()
                Settings:set("export_location_flat", true)
                rebuild(ctx)
            end,
        }
    ))

    local out_dir = sefirah_base_dir() .. "/"
        .. (ctx.novel.name or ctx.novel.title or "Roman"):gsub('[<>:"/\\|?*]', "_")
    table.insert(rows, P.makeRow("Sortie : " .. out_dir, { dim = true, callback = function() end }))

    table.insert(rows, P.hairline())
    table.insert(rows, P.makeRow("Lancer l'export", {
        bold = true,
        callback = function() Export.run(ctx) end,
    }))
    table.insert(rows, P.makeRow("Annuler", {
        callback = function() Export.close() end,
    }))

    local function on_back()
        Export.close()
    end

    -- Ferme l'ancien panneau avant d'afficher le nouveau
    if _panel then UIManager:close(_panel) end
    _panel = P.showSubPanel("Options d'export", rows, on_back, close_all)
    SefirahUI.setExport(_panel)
end

function Export.close()
    if _panel then
        UIManager:close(_panel)
        _panel = nil
    end
    local ok, SefirahUI = pcall(require, "ui.main_widget")
    if ok then SefirahUI.clearExport() end
end

return Export