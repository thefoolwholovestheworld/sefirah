-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- Onglet Sources : uniquement les sources Lua natives intégrées au plugin.
local UIManager   = require("ui/uimanager")
local ConfirmBox  = require("ui/widget/confirmbox")
local ExtMgr      = require("core.extmgr")
local Settings    = require("settings")
local P           = require("ui.panel")
local LangFilter  = require("ui.lang_filter")

local Sources = {}
local _page = 1

local function close_all()
    if _G.sefirah_close_all then _G.sefirah_close_all() end
end

local function rebuild()
    require("ui.main_widget").show("sources")
end

function Sources.ext_settings(meta)
    local SefirahUI = require("ui.main_widget")
    local ext = ExtMgr.get(meta.id)
    local sp = {}

    local function close_settings()
        if sp[1] then UIManager:close(sp[1]); sp[1] = nil end
        SefirahUI.clearDetail()
    end

    local rows = {
        P.makeRow("Source : " .. meta.name, { dim = true, callback = function() end }),
        P.makeRow("Version : " .. (meta.version or "native"), { dim = true, callback = function() end }),
        P.makeRow("Mode : Lua natif", { dim = true, callback = function() end }),
        P.makeRow("Site : " .. (meta.site or "?"), { dim = true, callback = function() end }),
    }

    if ext and ext.supports_page_mode then
        local pm = Settings:getExt(meta.id, "page_mode", false)
        table.insert(rows, P.makeRow("Mode Page : " .. (pm and "ACTIVÉ" or "DÉSACTIVÉ"), {
            callback = function()
                Settings:toggleExt(meta.id, "page_mode", false)
                close_settings()
                rebuild()
            end,
        }))
    end

    table.insert(rows, P.makeRow("← Retour", { callback = close_settings }))
    local p = P.showSubPanel(meta.name .. " — Réglages", rows, close_settings, close_all)
    sp[1] = p
    SefirahUI.setDetail(p)
end

function Sources.build_rows()
    local rows = {}

    local installed = ExtMgr.visible()
    if #installed == 0 then
        table.insert(rows, P.makeRow("(aucune source native)", { dim = true, callback = function() end }))
    else
        for _, meta in ipairs(installed) do
            local m = meta
            table.insert(rows, P.makeSourceRow(
                m.name,
                (m.lang or "Français") .. "  ·  " .. (m.site or ""), {
                    id = m.id,
                    mandatory = "Lua natif",
                    callback = function() Sources.ext_settings(m) end,
                    hold_callback = function()
                        UIManager:show(ConfirmBox:new{
                            text = m.name .. " est intégrée au plugin et ne peut pas être désinstallée.",
                            ok_callback = function() end,
                        })
                    end,
                }
            ))
        end
    end

    -- Pagination par hauteur RÉELLE des lignes, pas par un simple compte.
    -- Cet onglet mélange des lignes d'en-tête basses (P.ROW_H, via P.makeRow)
    -- et des lignes de source plus hautes (P.SOURCE_ROW_H, via P.makeSourceRow).
    -- L'ancien calcul (P.MAX_ROWS, prévu pour des lignes P.ROW_H uniquement)
    -- sous-estimait donc la hauteur totale dès qu'il y avait des sources
    -- installées : le contenu débordait de sa zone réservée et venait
    -- chevaucher/rogner la barre Bibliothèque / Parcourir / Sources en bas.
    -- On empile ici les lignes une à une par leur hauteur réelle, avec une
    -- marge de sécurité (P.MARGIN) — quitte à laisser une source de moins sur
    -- la page plutôt que de risquer un débordement.
    local budget = P.CONTENT_H - P.MARGIN
    local pages, cur, used = {}, {}, 0
    for _, r in ipairs(rows) do
        local h = r:getSize().h
        if used + h > budget and #cur > 0 then
            table.insert(pages, cur)
            cur, used = {}, 0
        end
        table.insert(cur, r)
        used = used + h
    end
    table.insert(pages, cur)

    local max_pages = #pages
    if _page > max_pages then _page = max_pages end
    local visible = pages[_page]

    local nav = max_pages > 1 and {
        page = _page,
        max_pages = max_pages,
        on_prev = _page > 1 and function() _page = _page - 1; rebuild() end or nil,
        on_next = _page < max_pages and function() _page = _page + 1; rebuild() end or nil,
    } or nil

    local actions = {
        -- Les résultats s'affichent dans l'onglet Parcourir.
        on_search = function() require("ui.browse").globalSearchPrompt() end,
        on_lang = function()
            LangFilter.show(function()
                _page = 1
                rebuild()
            end)
        end,
    }

    return visible, "Sources" .. ExtMgr.langTitleSuffix(), nav, actions
end

function Sources.close() end

return Sources
