-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- novelfrance.lua
-- Extension Sefirah pour https://novelfrance.fr
--
-- NovelFrance est une app Next.js qui embarque ses données (novel, liste de
-- chapitres, contenu du chapitre) sous forme de JSON dans le payload React
-- Server Components (les balises <script>self.__next_f.push([1,"..."])</script>).
-- On extrait ce JSON directement plutôt que de parser le HTML rendu, ce qui
-- est beaucoup plus fiable que du regex sur des classes Tailwind.
--
-- La liste complète des chapitres est récupérée via l'API JSON interne du
-- site (trouvée dans l'onglet Network des DevTools) :
--   GET /api/chapters/<slug>?skip=N&take=50&order=asc
--   -> { chapters: [...], total, skip, take, order, hasMore }
-- On boucle en incrémentant skip de 50 jusqu'à hasMore = false. C'est du
-- JSON standard, pas besoin de dé-échapper quoi que ce soit ici.
--
-- CHAPITRES VERROUILLÉS : les chapitres avec "isPremium": true sont
-- marqués locked = true et ne sont jamais téléchargés/affichés. C'est
-- volontaire : ce sont des chapitres en avance réservés aux abonnés
-- Premium de NovelFrance, cette extension ne cherche pas à les contourner.

local logger = require("logger")
local Epub   = require("core.epub")

local BASE = "https://novelfrance.fr"

-- ---------------------------------------------------------------------
-- HTTP
-- ---------------------------------------------------------------------

local function http_get(url)
    local https = require("ssl.https")
    local http  = require("socket.http")
    local ltn12 = require("ltn12")
    local sink  = {}
    local req   = url:match("^https") and https or http
    local ok, code = req.request {
        url     = url,
        sink    = ltn12.sink.table(sink),
        headers = {
            ["User-Agent"] = "Mozilla/5.0 (Linux; Android 9; KOReader)",
            ["Accept"]     = "text/html,application/xhtml+xml,*/*;q=0.8",
        },
        timeout = 20,
    }
    if not ok or code ~= 200 then
        logger.err("novelfrance: http_get failed:", url, tostring(code))
        return nil, code
    end
    return table.concat(sink)
end

local function url_encode(str)
    return (str:gsub("([^%w%-%.%_%~])", function(c)
        return string.format("%%%02X", c:byte())
    end))
end

-- ---------------------------------------------------------------------
-- JSON helpers
-- ---------------------------------------------------------------------

local function json_decode(str)
    local ok_j, JSON = pcall(require, "rapidjson")
    if not ok_j then JSON = require("json") end
    local ok, data = pcall(JSON.decode, str)
    if not ok then return nil end
    return data
end

-- The RSC payload is a JS string literal, so quotes/backslashes inside it
-- are escaped (\" and \\). Undo that so the fragment becomes valid JSON.
local function unescape_js(s)
    if not s then return nil end
    return (s:gsub("\\(.)", function(c)
        if c == "n" then return "\n"
        elseif c == "t" then return "\t"
        elseif c == "r" then return "\r"
        elseif c == '"' then return '"'
        elseif c == "\\" then return "\\"
        elseif c == "/" then return "/"
        -- Conserver les échappements JSON inconnus (notamment \uXXXX) :
        -- le décodeur JSON doit encore les voir pour restaurer les accents.
        else return "\\" .. c end
    end))
end

-- Find `\"<key>\":{ ... }` in the raw (still-escaped) HTML and return the
-- balanced {...} substring, still escaped. Returns nil if not found.
local function find_balanced_json_object(text, key, needle)
    if not text then return nil end
    needle = needle or ('"' .. key .. '":{')
    local s, e = text:find(needle, 1, true)
    if not s then return nil end

    -- Ne pas utiliser %%b{} ici : la description peut elle-même contenir des
    -- accolades. On parcourt donc le JSON en respectant les chaînes JSON et
    -- leurs échappements.
    local start = e
    local depth = 0
    local in_string = false
    local escaped = false
    for i = start, #text do
        local c = text:sub(i, i)
        if in_string then
            if escaped then
                escaped = false
            elseif c == "\\" then
                escaped = true
            elseif c == '"' then
                in_string = false
            end
        else
            if c == '"' then
                in_string = true
            elseif c == '{' then
                depth = depth + 1
            elseif c == '}' then
                depth = depth - 1
                if depth == 0 then
                    return text:sub(start, i)
                end
            end
        end
    end
    return nil
end

-- Compatibilité avec l'ancien payload HTML brut : dans certains builds Next.js
-- le JSON de initialNovel reste directement dans la chaîne échappée.
local function find_json_object(html, key)
    local raw = find_balanced_json_object(html, key, '\\"' .. key .. '\\":{')
    if raw then return raw end
    return find_balanced_json_object(html, key)
end

-- Extrait tout le flux texte Flight de Next.js. On cherche .push([1,"...")
-- plutôt qu'une forme exacte de self.__next_f, car Next.js change parfois le
-- préfixe généré autour de __next_f.
local function extract_rsc_push_strings(html)
    local chunks = {}
    local pos = 1
    local marker = '.push([1,"'
    while true do
        local a = html:find(marker, pos, true)
        if not a then break end
        local i = a + #marker
        local out = {}
        while i <= #html do
            local c = html:sub(i, i)
            if c == '"' then
                local bs = 0
                local j = i - 1
                while j >= 1 and html:sub(j, j) == "\\" do
                    bs = bs + 1
                    j = j - 1
                end
                if bs % 2 == 0 then break end
            end
            out[#out + 1] = c
            i = i + 1
        end
        chunks[#chunks + 1] = unescape_js(table.concat(out))
        pos = math.max(i + 1, a + 1)
    end
    return chunks
end

local function build_rsc_stream(html)
    return table.concat(extract_rsc_push_strings(html), "")
end

-- Fetch a page and decode a named JSON object from its RSC payload.
-- Important : on NovelFrance, initialNovel can be split over several Flight
-- rows. We therefore search the decoded Flight stream first, then only use the
-- old raw-HTML fallback if necessary.
local function fetch_json_field(url, key)
    local html, err = http_get(url)
    if not html then return nil, err end

    local stream = build_rsc_stream(html)
    local raw_stream = find_balanced_json_object(stream, key)
    if raw_stream then
        local decoded = json_decode(raw_stream)
        if decoded then return decoded end
    end

    local raw = find_json_object(html, key)
    if not raw then return nil, "field_not_found" end
    return json_decode(unescape_js(raw))
end

local function escape_html(s)
    if not s then return "" end
    return (s:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))
end

-- Le champ "description" renvoyé par l'API (initialNovel.description) est
-- stocké en HTML côté site (balises <p>/<br>, entités &...;) — normal sur
-- le site lui-même qui le rend tel quel dans le navigateur, mais affiché
-- BRUT (balises visibles, entités non décodées) une fois collé tel quel
-- dans un TextBoxWidget côté lecteur (cf. ui/detail.lua, résumé "buggé"
-- signalé le 2026-09-13). On réutilise Epub.html_to_text (déjà éprouvé pour
-- le corps des chapitres) pour obtenir le même texte propre que celui
-- affiché par le site — sans effet si la chaîne était déjà du texte brut
-- (aucune balise/entité à traiter).
-- Next.js Flight peut externaliser les longues chaînes dans des lignes
-- `id:T<hexlen>,<texte>`.  Les champs de initialNovel peuvent alors contenir
-- une référence `$<id>` au lieu du texte réel.  L'ancien parseur décodait le
-- JSON mais ne résolvait pas ces références, ce qui laissait apparaître des
-- morceaux comme `34:T622,\"]self.__next_f.push(...)` sur la liseuse.
local function build_rsc_text_rows(html)
    local stream = build_rsc_stream(html)
    local rows = {}
    local pos = 1
    while pos <= #stream do
        local s, e, id, hexlen = stream:find("([0-9a-zA-Z]+):T([0-9a-fA-F]+),", pos)
        if not s then break end
        local len = tonumber(hexlen, 16)
        if not len then
            pos = e + 1
        else
            local data_start = e + 1
            local data_end = data_start + len - 1
            if data_end > #stream then
                break
            end
            rows[id] = stream:sub(data_start, data_end)
            pos = data_end + 1
        end
    end
    return rows
end

local function resolve_rsc_string(s, rows)
    if type(s) ~= "string" or not rows then return s end
    local out = s
    -- Une référence peut elle-même pointer vers une autre ligne. Limite basse
    -- volontaire pour éviter toute boucle si NovelFrance envoie une référence
    -- cyclique ou malformée.
    for _ = 1, 8 do
        local changed = false
        out = out:gsub("%$([0-9a-zA-Z]+)", function(id)
            local v = rows[id]
            if v ~= nil then
                changed = true
                return v
            end
            return "$" .. id
        end)
        if not changed then break end
    end
    return out
end

local function clean_summary(s, rsc_rows)
    if not s or s == "" then return "" end
    s = resolve_rsc_string(s, rsc_rows)
    -- Filet de sécurité : une version du site peut encore laisser une ligne
    -- Flight au début de la valeur. On la retire avant le décodage HTML.
    s = s:gsub("^%s*%d+:T[0-9a-fA-F]+,", "")
    s = s:gsub("^%s*%$[0-9a-zA-Z]+%s*$", "")
    local ok, cleaned = pcall(Epub.html_to_text, s)
    if ok and type(cleaned) == "string" then
        cleaned = cleaned:gsub("^%s+", ""):gsub("%s+$", "")
        return cleaned
    end
    return s
end

local STATUS_MAP = {
    ONGOING   = "Ongoing",
    COMPLETED = "Completed",
    HIATUS    = "Hiatus",
    CANCELLED = "Cancelled",
}

local CHAPTERS_PER_PAGE = 50

-- ---------------------------------------------------------------------
-- Classements (/rankings)
-- ---------------------------------------------------------------------
--
-- https://novelfrance.fr/rankings affiche 2 rangées d'onglets : catégorie
-- (Général/Mieux notés/Plus lus/Populaires/Discutés) et période (Semaine/
-- Mois/Tout temps). Confirmé par captures Network d'un utilisateur réel
-- (2026-09-10, deux séries de captures) :
--
--   GET /api/rankings/weekly?skip=0&take=20            -- "Plus lus" + "Semaine"
--   GET /api/rankings/monthly?skip=0&take=20            -- "Plus lus" + "Mois"
--   GET /api/rankings/all-time?skip=0&take=20            -- "Plus lus" + "Tout temps"
--   GET /api/rankings/most-rated?skip=0&take=20          -- "Mieux notés" (période ignorée, PAS de &period=)
--   GET /api/rankings/most-bookmarked?skip=0&take=20&period=weekly  -- "Populaires"
--   GET /api/rankings/most-discussed?skip=0&take=20&period=weekly  -- "Discutés"
--   -> { novels: [...], total: N }, entrées plates (title, slug, coverImage,
--      author, rating, views, totalViews, _count.chapters, rank, ...).
--
-- Donc DEUX mécaniques différentes pour la période selon la catégorie :
--   - "Plus lus" : la période EST le segment de chemin (weekly/monthly/all-time),
--     pas de paramètre séparé.
--   - "Populaires"/"Discutés" : chemin fixe (most-bookmarked/most-discussed),
--     période en paramètre `&period=weekly|monthly|all-time`.
--   - "Mieux notés" : chemin fixe (most-rated), PAS de paramètre période du
--     tout (confirmé : même requête quelle que soit la période affichée).
-- resolve_ranking_api() ci-dessous encode ces trois cas.
--
-- ⚠️ "Général" (combiné) : pas de requête XHR observée sur le site pour ce
-- cas. Reconstruit LOCALEMENT à la place (moyenne des positions dans les 4
-- classements ci-dessus) — voir compute_general() plus bas pour le détail.
-- Si tu trouves un jour la vraie URL du site pour "Général", dis-le-moi et
-- on pourra basculer dessus (plus fiable qu'une reconstruction locale).
local RANKING_CATEGORIES = {
    { id = "general",         label = "Général" },
    { id = "top_rated",       label = "Mieux notés" },
    { id = "most_read",       label = "Plus lus" },
    { id = "popular",         label = "Populaires" },
    { id = "most_discussed",  label = "Discutés" },
}
local RANKING_PERIODS = {
    { id = "week",  label = "Semaine" },
    { id = "month", label = "Mois" },
    { id = "all",   label = "Tout temps" },
}

-- id de période interne -> segment/valeur d'API confirmé.
local PERIOD_API = { week = "weekly", month = "monthly", all = "all-time" }

-- (catégorie, période) -> (segment de chemin /api/rankings/<segment>,
-- paramètre de query string additionnel ou nil, confirmé ou deviné).
local function resolve_ranking_api(category_id, period_id)
    local period_seg = PERIOD_API[period_id] or "weekly"
    if category_id == "most_read" then
        return period_seg, nil, true
    elseif category_id == "top_rated" then
        return "most-rated", nil, true
    elseif category_id == "popular" then
        return "most-bookmarked", "&period=" .. period_seg, true
    elseif category_id == "most_discussed" then
        return "most-discussed", "&period=" .. period_seg, true
    end
    -- N'est normalement jamais atteint pour category_id == "general" : ce cas
    -- est intercepté plus tôt dans ext:popularNovels (voir compute_general).
    -- Filet de sécurité pour un id de catégorie inconnu.
    return "most-rated", nil, true
end

-- Essaie plusieurs noms de clé RSC possibles pour le JSON embarqué dans la
-- page HTML /rankings (utilisé uniquement en dernier repli, quand l'API JSON
-- directe /api/rankings/<slug> échoue) — liste de suppositions par ordre de
-- plausibilité (même convention que `initialNovel`/`initialChapter` ailleurs
-- dans ce fichier).
local RANKING_JSON_KEYS = { "initialRankings", "rankingsData", "rankings", "searchResults" }

local function find_rankings_json(html)
    for _, key in ipairs(RANKING_JSON_KEYS) do
        local raw = find_json_object(html, key)
        if raw then
            local data = json_decode(unescape_js(raw))
            if data then return data, key end
        end
    end
    return nil, nil
end

-- Un item de classement peut être une entrée "plate" (title/slug directement
-- dessus — confirmé pour /api/rankings/<type>) ou imbriquée sous `.novel`
-- (au cas où la forme diffère sur la page /rankings servie en repli) — on
-- gère les deux défensivement.
local function ranking_item_to_novel(item)
    local n = item.novel or item
    if not n or not n.slug then return nil end
    return {
        name   = n.title,
        path   = "/novel/" .. n.slug,
        cover  = n.coverImage and (BASE .. n.coverImage) or nil,
        author = n.author,
    }
end

-- ---------------------------------------------------------------------
-- "Général" reconstruit localement (aucun endpoint confirmé pour ce cas —
-- voir le commentaire au-dessus de RANKING_CATEGORIES) : moyenne des
-- positions dans les 4 classements confirmés (Mieux notés, Plus lus,
-- Populaires, Discutés). Chaque sous-liste est ramenée à un score
-- normalisé 0..1 selon le RANG (1er = 1.0, dernier récupéré = 0.0) plutôt
-- que la valeur brute, pour pouvoir moyenner des métriques d'échelles très
-- différentes (note sur 5, vues, favoris, messages) sans qu'une écrase les
-- autres. Un roman absent d'une sous-liste compte pour 0 sur celle-ci
-- (pénalise plutôt que d'ignorer, pour éviter qu'un roman visible dans une
-- seule petite liste de niche ne monte artificiellement en tête).
--
-- Semaine : PAS de requête "weekly" dédiée pour ce calcul — on réutilise les
-- données "Mois" (divisées par 4, comme demandé) pour éviter 3 requêtes
-- API en plus. Note honnête : cette division ne change PAS l'ordre final —
-- diviser une liste entière par la même constante ne modifie pas son
-- classement interne (le score normalisé par rang serait strictement
-- identique avec ou sans la division). Elle est appliquée quand même sur
-- la valeur brute, uniquement par cohérence avec ce qui a été demandé.
local GENERAL_FETCH_N   = 40  -- profondeur récupérée par sous-classement
local GENERAL_CACHE_TTL = 600 -- secondes ; évite de tout re-fetcher à chaque page tournée
local GENERAL_CACHE = {}      -- [period_id] = { items = {...}, ts = os.time() }

local function fetch_ranking_list(path, extra_qs, n)
    local url = string.format("%s/api/rankings/%s?skip=0&take=%d%s", BASE, path, n, extra_qs or "")
    local body = http_get(url)
    local data = body and json_decode(body)
    if not data or not data.novels then return {} end
    return data.novels
end

-- Valeur brute utilisée par une sous-liste, avant normalisation par rang
-- (uniquement pour appliquer la division /4 "Semaine" demandée ci-dessus —
-- n'affecte pas le score final, voir la note plus haut).
local function apply_period_divisor(items, kind, divisor)
    if divisor == 1 then return items end
    for _, item in ipairs(items) do
        if kind == "views" and item.views then item.views = item.views / divisor
        elseif kind == "bookmarks" and item.bookmarkCount then item.bookmarkCount = item.bookmarkCount / divisor
        elseif kind == "discussions" then
            if item.stats and item.stats.discussionCount then
                item.stats.discussionCount = item.stats.discussionCount / divisor
            elseif item.discussionCount then
                item.discussionCount = item.discussionCount / divisor
            end
        end
    end
    return items
end

local function compute_general(period_id)
    local now = os.time()
    local cached = GENERAL_CACHE[period_id]
    if cached and (now - cached.ts) < GENERAL_CACHE_TTL then
        return cached.items
    end

    local sub_period = (period_id == "week") and "month" or period_id
    local sub_seg     = PERIOD_API[sub_period] or "monthly"
    local divisor      = (period_id == "week") and 4 or 1

    local lists = {
        fetch_ranking_list("most-rated", nil, GENERAL_FETCH_N),
        apply_period_divisor(fetch_ranking_list(sub_seg, nil, GENERAL_FETCH_N), "views", divisor),
        apply_period_divisor(fetch_ranking_list("most-bookmarked", "&period=" .. sub_seg, GENERAL_FETCH_N), "bookmarks", divisor),
        apply_period_divisor(fetch_ranking_list("most-discussed", "&period=" .. sub_seg, GENERAL_FETCH_N), "discussions", divisor),
    }

    local scores = {} -- [slug] = { total = N, novel = {...} }
    for _, list in ipairs(lists) do
        local n = #list
        if n > 0 then
            for i, item in ipairs(list) do
                if item.slug then
                    local rank_score = (n > 1) and ((n - i) / (n - 1)) or 1 -- 1er = 1.0, dernier = 0.0
                    local entry = scores[item.slug]
                    if not entry then
                        entry = { total = 0, novel = ranking_item_to_novel(item) }
                        scores[item.slug] = entry
                    end
                    entry.total = entry.total + rank_score
                end
            end
        end
    end

    local merged = {}
    for _, entry in pairs(scores) do
        if entry.novel then
            entry.avg = entry.total / #lists -- sur 4 classements ; absence d'une liste = 0 sur celle-ci
            table.insert(merged, entry)
        end
    end
    table.sort(merged, function(a, b) return a.avg > b.avg end)

    local items = {}
    for _, entry in ipairs(merged) do table.insert(items, entry.novel) end

    GENERAL_CACHE[period_id] = { items = items, ts = now }
    return items
end

-- Loop over the internal chapters API until every chapter has been fetched.
-- Returns a plain array of raw chapter objects (title, slug, chapterNumber,
-- isPremium, ...), or {} on failure.
-- Ce tableau est utilisé TEL QUEL comme liste de chapitres à exporter
-- (ui/export.lua -> ctx.chapters -> Epub.export), sans être re-trié avant
-- l'écriture de l'EPUB — l'ordre renvoyé ici EST l'ordre du fichier final.
-- On récupère toujours les pages en order=asc (skip stable même si de
-- nouveaux chapitres sont publiés pendant la boucle — cf. le gros
-- commentaire sur parsePage plus bas), puis on inverse le tableau une fois
-- complet pour renvoyer les chapitres du plus récent au plus ancien.
local function fetch_all_chapters(slug)
    local chapters = {}
    local skip = 0
    while true do
        local url = string.format("%s/api/chapters/%s?skip=%d&take=%d&order=asc",
            BASE, slug, skip, CHAPTERS_PER_PAGE)
        local body, err = http_get(url)
        if not body then
            logger.err("novelfrance: fetch_all_chapters failed at skip=", skip, tostring(err))
            break
        end
        local data = json_decode(body)
        if not data or not data.chapters then
            logger.err("novelfrance: fetch_all_chapters got invalid JSON at skip=", skip)
            break
        end
        for _, c in ipairs(data.chapters) do
            table.insert(chapters, c)
        end
        if not data.hasMore then
            break
        end
        skip = skip + CHAPTERS_PER_PAGE
    end

    -- Inversion finale : chapters est en ordre croissant (1, 2, 3 ... N) à ce
    -- stade (pagination order=asc ci-dessus) ; demandé plus tard dans l'ordre
    -- inverse (N, N-1 ... 1) pour la liste exportée.
    local reversed = {}
    for i = #chapters, 1, -1 do
        reversed[#reversed + 1] = chapters[i]
    end
    return reversed
end

-- ---------------------------------------------------------------------
-- Extension
-- ---------------------------------------------------------------------

local ext = {
    id      = "novelfrance",
    name    = "NovelFrance",
    site    = BASE,
    lang    = "fr",
    version = "1.0.0",
    maxReviews = 150, -- limite d'avis affichés (même valeur pour toutes les extensions) : au-delà, plus de page à droite
}

-- Lu par sefirah.koplugin/ui/browse.lua : affiche l'icône de tri sur
-- l'onglet Parcourir → Populaire et construit l'écran de filtres à deux
-- colonnes (Catégorie / Période) + bouton Appliquer. La sélection est
-- renvoyée dans `options.filters = { category = <id>, period = <id> }` à
-- ext:popularNovels, qui les combine via resolve_ranking_api() (voir le
-- commentaire au-dessus de RANKING_CATEGORIES — la période n'a d'effet
-- réel que pour la catégorie "Plus lus").
ext.popularFilters = {
    {
        key     = "category",
        label   = "Catégorie",
        default = "top_rated", -- "Mieux notés" — confirmé fonctionner (200 OK), indépendant de la période
        options = (function()
            local o = {}
            for _, c in ipairs(RANKING_CATEGORIES) do
                table.insert(o, { id = c.id, label = c.label })
            end
            return o
        end)(),
    },
    {
        key     = "period",
        label   = "Période",
        default = "week",
        options = (function()
            local o = {}
            for _, p in ipairs(RANKING_PERIODS) do
                table.insert(o, { id = p.id, label = p.label })
            end
            return o
        end)(),
    },
}

-- Onglet Parcourir → Populaire = page /rankings du site (Hall of Fame).
-- Voir le commentaire au-dessus de RANKING_CATEGORIES pour le détail de ce
-- qui est confirmé (weekly/monthly/most-rated) et deviné (le reste).
function ext:popularNovels(page, options)
    local filters   = options and options.filters
    local category  = (filters and filters.category) or "top_rated"
    local period    = (filters and filters.period) or "week"

    -- take=6 : voir le commentaire plus bas ; s'applique aussi ici pour la
    -- pagination du classement "Général" reconstruit localement.
    local take = 6
    local skip = ((page or 1) - 1) * take

    if category == "general" then
        local items = compute_general(period)
        local novels = {}
        for i = skip + 1, math.min(#items, skip + take) do
            table.insert(novels, items[i])
        end
        return { novels = novels }
    end

    local path, extra_qs, confirmed = resolve_ranking_api(category, period)

    -- 6, PAS 20 : l'app (sefirah.koplugin/ui/browse.lua) affiche 6 romans par
    -- page en mode grille (2 rangées × 3 colonnes) et enchaîne automatiquement
    -- plusieurs appels à popularNovels(page, ...) si un seul n'en fournit pas
    -- assez pour remplir l'écran — mais elle ne redécoupe PAS un lot trop
    -- grand renvoyé par un seul appel. Avec take=20, le 1er appel renvoyait à
    -- lui seul de quoi remplir l'écran (20 ≥ 6), donc l'app considérait cette
    -- tranche de 20 comme "consommée" en entier et repartait de skip=20 pour
    -- la page suivante — les romans 7 à 20 n'étaient jamais affichés, cassant
    -- la continuité 1-6 / 7-12 / 13-18 attendue. En alignant take sur la
    -- taille d'une page d'écran, chaque appel = exactement une page app.
    local url  = string.format("%s/api/rankings/%s?skip=%d&take=%d%s", BASE, path, skip, take, extra_qs or "")

    local body = http_get(url)
    local data = body and json_decode(body)

    if (not data or not data.novels) and not confirmed then
        -- Repli : "most-rated" est CONFIRMÉ fonctionner (200 OK observé en
        -- capture réelle), contrairement au slug deviné ("general", pour
        -- l'instant le seul cas encore non confirmé). Mieux vaut afficher
        -- "Mieux notés" que rien du tout.
        logger.warn("novelfrance: /api/rankings/" .. path ..
            " a échoué ou renvoyé un JSON inattendu, repli sur most-rated")
        body = http_get(string.format("%s/api/rankings/most-rated?skip=%d&take=%d", BASE, skip, take))
        data = body and json_decode(body)
    end

    if not data or not data.novels then
        -- Repli n°2, dernier recours : page /rankings rendue côté serveur
        -- (RSC) — la forme du JSON qu'elle embarque n'est pas confirmée
        -- (voir RANKING_JSON_KEYS plus haut), donc ce chemin peut lui aussi
        -- échouer silencieusement.
        logger.warn("novelfrance: repli most-rated aussi en échec, tentative sur la page /rankings")
        local html, err2 = http_get(BASE .. "/rankings")
        if not html then
            logger.err("novelfrance: popularNovels — repli /rankings a aussi échoué", tostring(err2))
            return { novels = {} }
        end
        data = find_rankings_json(html)
        if not data then
            logger.err("novelfrance: popularNovels — aucune donnée exploitable (ni API JSON, ni RSC)")
            return { novels = {} }
        end
    end

    local raw_items = data.novels or data.rankings or data.items or data
    local novels = {}
    if type(raw_items) == "table" then
        for _, item in ipairs(raw_items) do
            local n = ranking_item_to_novel(item)
            if n then table.insert(novels, n) end
        end
    end

    if #novels == 0 then
        logger.err("novelfrance: popularNovels — 0 roman extrait pour", url)
    end
    return { novels = novels }
end

function ext:searchNovels(term, page)
    -- NovelFrance's search is a client-side instant-search widget (no
    -- dedicated /search page), backed by this JSON endpoint. It returns a
    -- flat top-N list of matches with no pagination — `page` is accepted
    -- for API-contract compatibility but has no effect here.
    local url = BASE .. "/api/search/autocomplete?q=" .. url_encode(term)
    local body, err = http_get(url)
    if not body then
        logger.err("novelfrance: searchNovels fetch failed", tostring(err))
        return { novels = {} }
    end

    local data = json_decode(body)
    if not data then
        logger.err("novelfrance: searchNovels invalid JSON for", term)
        return { novels = {} }
    end

    local novels = {}
    for _, n in ipairs(data) do
        table.insert(novels, {
            name   = n.title,
            path   = "/novel/" .. n.slug,
            cover  = n.coverImage and (BASE .. n.coverImage) or nil,
            author = n.author,
        })
    end
    return { novels = novels }
end

function ext:parseNovelMeta(path)
    local html, err = http_get(BASE .. path)
    if not html then
        logger.err("novelfrance: parseNovelMeta failed for", path, tostring(err))
        return { name = "", path = path, total_chapters = 0 }
    end
    local rsc_stream = build_rsc_stream(html)
    local novel_raw = find_balanced_json_object(rsc_stream, "initialNovel")
    local novel = novel_raw and json_decode(novel_raw)
    if not novel then
        novel_raw = find_json_object(html, "initialNovel")
        novel = novel_raw and json_decode(unescape_js(novel_raw))
    end
    if not novel then
        logger.err("novelfrance: parseNovelMeta invalid initialNovel for", path)
        return { name = "", path = path, total_chapters = 0 }
    end
    local rsc_rows = build_rsc_text_rows(html)

    return {
        name           = novel.title,
        path           = path,
        cover          = novel.coverImage and (BASE .. novel.coverImage) or nil,
        summary        = clean_summary(novel.description, rsc_rows),
        author         = novel.author,
        status         = STATUS_MAP[novel.status] or "Unknown",
        rating         = novel.rating,
        rank           = novel.allTimeRank,
        total_chapters = (novel._count and novel._count.chapters) or 0,
    }
end

-- Confirmé par capture Network (2026-09-12) : l'API accepte order=asc (en
-- plus de desc, utilisé par fetch_all_chapters ci-dessus) —
--   GET /api/chapters/<slug>?skip=0&take=5&order=asc
--   -> chapterNumber 0,1,2,3,4 (les tout premiers), total, hasMore
-- IMPORTANT : parsePage() a BESOIN de order=asc, PAS desc. detail.lua
-- (Detail.fetch, récupération "delta") suppose que le numéro de page d'un
-- chapitre est stable dans le temps — les nouveaux chapitres s'ajoutent
-- uniquement à la fin, sur de nouvelles pages, sans jamais faire bouger les
-- anciens. En desc (skip=0 = les plus récents), l'inverse se produit : tout
-- décale d'une page à chaque nouveau chapitre publié, ce qui casserait
-- complètement la fusion incrémentale de detail.lua.
ext.chapters_per_page = CHAPTERS_PER_PAGE

-- Une page de chapitres (1-based), déjà mappée au même format que
-- ext:parseNovel (name/path/chapter_number/date/locked) — pas les champs
-- bruts de l'API. Permet à ui/detail.lua de ne récupérer QUE les nouvelles
-- pages quand le nombre de chapitres augmente, au lieu de tout retélécharger
-- via parseNovel (fetch_all_chapters) à chaque "Actualiser la liste des
-- chapitres". Sur un roman à plusieurs milliers de chapitres (Shadow Slave,
-- 3180+), un parseNovel complet fait ~32 requêtes HTTP synchrones
-- d'affilée sans jamais rendre la main à l'UI — symptôme observé : l'appli
-- se ferme/redémarre (probablement un timeout système faute de réponse de
-- l'UI, pas un vrai crash logiciel). parsePage() rend chaque "Actualiser"
-- normal (pas de nouveaux chapitres) instantané, et un vrai ajout de
-- chapitres ne coûte plus qu'une poignée de requêtes au lieu de 32+.
function ext:parsePage(path, page)
    local base_path = path:gsub("/+$", "")
    local slug = base_path:match("([^/]+)$")
    page = tonumber(page) or 1
    local skip = (page - 1) * CHAPTERS_PER_PAGE

    local url = string.format("%s/api/chapters/%s?skip=%d&take=%d&order=asc",
        BASE, slug, skip, CHAPTERS_PER_PAGE)
    local body, err = http_get(url)
    if not body then
        logger.err("novelfrance: parsePage fetch failed for", slug, "page", page, tostring(err))
        return { chapters = {} }
    end

    local data = json_decode(body)
    if not data or not data.chapters then
        logger.err("novelfrance: parsePage invalid JSON for", slug, "page", page)
        return { chapters = {} }
    end

    local chapters = {}
    for _, c in ipairs(data.chapters) do
        table.insert(chapters, {
            name           = c.title,
            path           = base_path .. "/" .. c.slug,
            chapter_number = c.chapterNumber,
            date           = c.publishedAt or c.createdAt or c.date or c.updatedAt,
            locked         = c.isPremium or nil,
        })
    end
    return { chapters = chapters }
end

function ext:parseNovel(path)
    local base_path = path:gsub("/+$", "")
    local html, err = http_get(BASE .. path)
    if not html then
        logger.err("novelfrance: parseNovel fetch failed for", path, tostring(err))
        return { name = "", path = path, chapters = {}, totalPages = 1 }
    end

    local rsc_stream = build_rsc_stream(html)
    local novel_raw = find_balanced_json_object(rsc_stream, "initialNovel")
    local novel = novel_raw and json_decode(novel_raw)
    if not novel then
        novel_raw = find_json_object(html, "initialNovel")
        novel = novel_raw and json_decode(unescape_js(novel_raw))
    end
    if not novel then
        logger.err("novelfrance: could not parse initialNovel for", path)
        return { name = "", path = path, chapters = {}, totalPages = 1 }
    end

    local rsc_rows = build_rsc_text_rows(html)

    -- Prefer the slug parsed from the path itself (matches novel.slug in
    -- practice, but doesn't depend on it being present/correct).
    local slug = base_path:match("([^/]+)$") or novel.slug

    local raw_chapters = fetch_all_chapters(slug)
    local chapters = {}
    for _, c in ipairs(raw_chapters) do
        table.insert(chapters, {
            name           = c.title,
            path           = base_path .. "/" .. c.slug,
            chapter_number = c.chapterNumber,
            date           = c.publishedAt or c.createdAt or c.date or c.updatedAt,
            locked         = c.isPremium or nil,
        })
    end
    if #chapters == 0 then
        logger.err("novelfrance: fetch_all_chapters returned no chapters for", slug)
    end

    local genres = nil
    if novel.genres then
        local names = {}
        for _, g in ipairs(novel.genres) do table.insert(names, g.name) end
        genres = table.concat(names, ", ")
    end

    -- Note moyenne (ex. "4.9") et rang dans un classement (ex. "#1"), affichés
    -- sur la page détail du site juste sous la couverture. Confirmés par une
    -- vraie capture du JSON initialNovel (2026-09-11) :
    --   "rating":4.897959183673469, "ratingCount":98, ..., "allTimeRank":1
    -- rating est un flottant brut (arrondi à l'affichage, pas ici) ; allTimeRank
    -- n'existe probablement que pour les romans classés (nil sinon → pas de
    -- badge affiché, cf. ui/detail.lua).
    local rating = novel.rating
    local rank   = novel.allTimeRank

    return {
        name       = novel.title,
        path       = path,
        cover      = novel.coverImage and (BASE .. novel.coverImage) or nil,
        summary    = clean_summary(novel.description, rsc_rows),
        author     = novel.author,
        genres     = genres,
        status     = STATUS_MAP[novel.status] or "Unknown",
        rating     = rating,
        rank       = rank,
        chapters   = chapters,
        totalPages = 1,
    }
end

-- ---------------------------------------------------------------------
-- Commentaires par paragraphe (/api/comments/chapter/...)
-- ---------------------------------------------------------------------
--
-- Confirmé par capture Network (2026-09-11), fil complet d'UN paragraphe :
--   GET /api/comments/chapter/<chapterId>/paragraph/<paragraphId>?sortBy=newest&page=N&limit=100
--   -> { comments: [...], total, page, limit, hasMore }
-- Chaque entrée de `comments` porte son propre paragraphId (utile pour un
-- éventuel threading côté client) et parentId (null pour un commentaire
-- racine, sinon l'id du commentaire parent — cf. replyTo pour l'extrait
-- affiché par le site).
--
-- as_str() : même nécessité que pour les avis (cf. plus bas) — certaines
-- libs JSON Lua décodent `null` en une valeur sentinelle, pas un vrai nil.
local function as_str(v)
    if type(v) == "string" and v ~= "" then return v end
    return nil
end
-- BUG CORRIGÉ (2026-09-12) : double antislash dans le pattern gmatch
-- ("\\1" au lieu de "\1", etc.) — en Lua, dans une chaîne entre guillemets,
-- "\1" est l'échappement décimal produisant l'OCTET de valeur 1, alors que
-- "\\1" produit DEUX octets littéraux : un antislash suivi du caractère '1'.
-- Le pattern voulu (classe de caractères UTF-8 standard : octet de tête
-- 0x01-0x7F/0xC2-0xF4 suivi de 0 à 3 octets de continuation 0x80-0xBF)
-- devenait donc une classe de caractères ASCII complètement différente et
-- sans rapport (des antislashs/chiffres littéraux), qui ne matchait quasi
-- rien dès le premier caractère accentué — `utf8_prefix("Il régarda...", 80)`
-- renvoyait juste "I" au lieu de toute la phrase. Résultat concret : pour
-- tout texte français normal (accents), le `needle` construit ci-dessous
-- était tronqué à quasi rien, et readerview.lua ne retrouvait plus JAMAIS
-- la position du paragraphe dans le texte affiché → aucune icône 💬,
-- quel que soit le paragraphe. Fix : un seul antislash (vrais octets).
local function utf8_prefix(s, n)
    s = s or ""
    local out, count = {}, 0
    for c in s:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        count = count + 1
        if count > n then break end
        table.insert(out, c)
    end
    return table.concat(out)
end

-- BUG CORRIGÉ (2026-09-12) : certains paragraphes renvoyés par l'API du site
-- portent DÉJÀ un repère "[N avis]" en toutes lettres, directement à
-- l'intérieur de `p.content` — ce n'est PAS quelque chose que ce plugin
-- ajoutait lui-même (cf. fetch_chapter_comment_counts et le champ `marks`
-- plus bas, un mécanisme totalement séparé, basé sur un second endpoint
-- /paragraph-counts). Comme rien ne retirait jamais ce texte de p.content
-- avant affichage, il apparaissait tel quel, en clair et non tapable, dans
-- le chapitre affiché — dupliquant, sans aucune interaction possible, ce
-- que l'icône comment.png (superposée par ui/readerview.lua) est censée
-- représenter.
-- Fix : on détecte ce repère, on l'enlève du texte affiché, et on récupère
-- le nombre qu'il contient comme repli si /paragraph-counts n'a pas cette
-- entrée (ex. léger désaccord entre les deux endpoints du site) — pour que
-- CE paragraphe obtienne quand même son icône tapable, plutôt que de perdre
-- purement et simplement l'information de commentaire.
local function strip_inline_avis_marker(text)
    text = text or ""
    -- "avis" est invariable en français (identique au singulier et au
    -- pluriel) : pas besoin de gérer un "s" optionnel ici.
    local n = text:match("%s*%[%s*(%d+)%s+avis%s*%]%s*$")
    if not n then return text, nil end
    local stripped = text:gsub("%s*%[%s*%d+%s+avis%s*%]%s*$", "")
    return stripped, tonumber(n)
end


-- Résolution d'URL d'avatar partagée entre avis (comment_to_review, section
-- "Avis" plus bas) et commentaires de paragraphe (comment_to_paragraph_comment
-- ci-dessous) : mêmes variantes de champ possibles, même règle pour les
-- chemins relatifs (/uploads/avatars/...) à préfixer par BASE.
local function resolve_avatar_url(author)
    local avatar = as_str(author.avatar) or as_str(author.avatarUrl)
        or as_str(author.image) or as_str(author.imageUrl)
    if avatar and not avatar:match("^https?://") then
        avatar = BASE .. avatar
    end
    return avatar
end

-- Confirmé par capture Network (2026-09-11) : il existe un endpoint dédié
-- pour l'aperçu par chapitre, distinct du fil complet d'un paragraphe —
-- pas besoin de regrouper une liste de commentaires nous-mêmes :
--   GET /api/comments/chapter/<chapterId>/paragraph-counts
--   -> { "<paragraphId>": <count>, "<paragraphId>": <count>, ... }
-- (objet JSON brut, pas de champ "comments"/"hasMore" — un simple map
-- paragraphId -> nombre de commentaires sur CE paragraphe.)
local function fetch_chapter_comment_counts(chapter_id)
    local url = string.format(
        "%s/api/comments/chapter/%s/paragraph-counts",
        BASE, url_encode(chapter_id))
    local body, err = http_get(url)
    if not body then
        logger.err("novelfrance: fetch_chapter_comment_counts failed for", chapter_id, tostring(err))
        return {}
    end

    local data = json_decode(body)
    if not data or type(data) ~= "table" then
        logger.err("novelfrance: fetch_chapter_comment_counts invalid JSON for", chapter_id)
        return {}
    end

    -- data est déjà le map paragraphId -> count attendu par parseChapter ;
    -- on filtre juste les valeurs non numériques par prudence (une lib JSON
    -- Lua mal lunée pourrait décoder un compteur en string).
    local counts = {}
    for pid, n in pairs(data) do
        n = tonumber(n)
        if n and n > 0 then
            counts[pid] = n
        end
    end
    return counts
end

-- Contrat normalisé (même esprit que comment_to_review) : { id, author,
-- avatar, content, date, likes, dislikes, parent_id, reply_count }.
-- parent_id/reply_count sont conservés (pas juste ignorés comme pour les
-- avis) car le fil d'un paragraphe est threadé (réponses imbriquées),
-- contrairement aux avis qui sont une simple liste plate.
local function comment_to_paragraph_comment(c)
    if not c then return nil end
    local author    = c.author or {}
    local reactions = c.reactions or {}

    return {
        id          = as_str(c.id),
        author      = as_str(author.username) or "Anonyme",
        avatar      = resolve_avatar_url(author),
        content     = as_str(c.content) or "",
        date        = as_str(c.createdAt) or as_str(c.publishedAt)
            or as_str(c.date) or as_str(c.updatedAt),
        likes       = reactions.like,
        dislikes    = reactions.dislike,
        parent_id   = as_str(c.parentId),
        reply_count = c.replyCount,
    }
end

-- Fil complet d'un paragraphe donné (pas encore branché à une UI — pour
-- l'instant seul parseChapter s'en sert indirectement via le repère
-- "[N avis]" ; cette méthode sert à récupérer le détail quand on tape
-- dessus, une fois l'écran correspondant construit côté ui/).
function ext:parseParagraphComments(chapter_id, paragraph_id, page)
    page = page or 1
    local url = string.format(
        "%s/api/comments/chapter/%s/paragraph/%s?sortBy=newest&page=%d&limit=100",
        BASE, url_encode(chapter_id), url_encode(paragraph_id), page)
    local body, err = http_get(url)
    if not body then
        logger.err("novelfrance: parseParagraphComments fetch failed for", chapter_id, paragraph_id, "page", page, tostring(err))
        return { comments = {}, has_more = false }
    end

    local data = json_decode(body)
    if not data or not data.comments then
        logger.err("novelfrance: parseParagraphComments invalid JSON for", chapter_id, paragraph_id, "page", page)
        return { comments = {}, has_more = false }
    end

    local comments = {}
    for _, c in ipairs(data.comments) do
        -- pcall : un champ inattendu sur UN commentaire ne doit jamais faire
        -- perdre tout le fil (même raisonnement que pour parseReviews).
        local ok_c, r = pcall(comment_to_paragraph_comment, c)
        if ok_c and r then
            table.insert(comments, r)
        elseif not ok_c then
            logger.err("novelfrance: comment_to_paragraph_comment failed for", tostring(c and c.id), tostring(r))
        end
    end

    return { comments = comments, has_more = data.hasMore or false }
end

-- ---------------------------------------------------------------------
-- Commentaires de FIN DE CHAPITRE (/api/comments/chapter/<id>, SANS le
-- suffixe /paragraph/<paragraphId>)
-- ---------------------------------------------------------------------
--
-- Confirmé par capture Network (2026-09-12) : le site affiche, sous le
-- texte de chaque chapitre, une section "Commentaires" distincte des
-- commentaires PAR paragraphe (ceux-ci ont paragraphId = null, type =
-- "CHAPTER") :
--   GET /api/comments/chapter/<chapterId>?sortBy=newest&page=N&limit=20
--   -> { comments: [...], total, page, limit, hasMore }
-- Même forme d'entrée par commentaire que /paragraph/<id> (author,
-- content, reactions, createdAt, parentId pour une réponse) : on
-- réutilise donc directement comment_to_paragraph_comment ci-dessus pour
-- la conversion — pas besoin d'une fonction de mapping séparée.
function ext:parseChapterComments(chapter_id, page)
    page = page or 1
    local url = string.format(
        "%s/api/comments/chapter/%s?sortBy=newest&page=%d&limit=20",
        BASE, url_encode(chapter_id), page)
    local body, err = http_get(url)
    if not body then
        logger.err("novelfrance: parseChapterComments fetch failed for", chapter_id, "page", page, tostring(err))
        return { comments = {}, has_more = false, total = 0 }
    end

    local data = json_decode(body)
    if not data or not data.comments then
        logger.err("novelfrance: parseChapterComments invalid JSON for", chapter_id, "page", page)
        return { comments = {}, has_more = false, total = 0 }
    end

    local comments = {}
    for _, c in ipairs(data.comments) do
        -- pcall : un champ inattendu sur UN commentaire ne doit jamais faire
        -- perdre toute la section (même raisonnement que pour les avis et
        -- les commentaires par paragraphe).
        local ok_c, r = pcall(comment_to_paragraph_comment, c)
        if ok_c and r then
            table.insert(comments, r)
        elseif not ok_c then
            logger.err("novelfrance: comment_to_paragraph_comment (fin de chapitre) failed for", tostring(c and c.id), tostring(r))
        end
    end

    return { comments = comments, has_more = data.hasMore or false, total = tonumber(data.total) or #comments }
end

-- dd/mm/yyyy à partir d'une date ISO ("2026-09-10T19:12:52.206Z") — même
-- logique que format_comment_date dans ui/readerview.lua, dupliquée ici car
-- non exportée par ce module (novelfrance.lua ne dépend pas de ui/).
local function format_chapter_comment_date(date)
    if not date or date == "" then return nil end
    local y, m, d = tostring(date):match("^(%d%d%d%d)-(%d%d)-(%d%d)")
    if not y then return nil end
    return string.format("%s/%s/%s", d, m, y)
end

function ext:parseChapter(path)
    local html, err = http_get(BASE .. path)
    if not html then
        logger.err("novelfrance: parseChapter fetch failed for", path, tostring(err))
        return "<p>Impossible de récupérer ce chapitre.</p>"
    end

    -- FIX : comme pour initialNovel (cf. parseNovel/parseNovelMeta), initialChapter
    -- peut lui aussi être découpé sur plusieurs lignes du flux Flight de Next.js.
    -- L'ancien code ne cherchait QUE dans le HTML brut échappé (find_json_object),
    -- ce qui ratait l'objet (ou récupérait un fragment tronqué) dès que le JSON du
    -- chapitre était réparti sur plusieurs push() — d'où "Impossible d'extraire le
    -- contenu de ce chapitre" sur des chapitres pourtant valides. On cherche
    -- désormais D'ABORD dans le flux Flight déjà reconstitué (fiable même réparti),
    -- et on ne retombe sur l'ancienne méthode qu'en dernier recours.
    local rsc_stream = build_rsc_stream(html)
    local chapter_raw = find_balanced_json_object(rsc_stream, "initialChapter")
    local chapter = chapter_raw and json_decode(chapter_raw)
    if not chapter then
        chapter_raw = find_json_object(html, "initialChapter")
        chapter = chapter_raw and json_decode(unescape_js(chapter_raw))
    end
    if not chapter then
        logger.err("novelfrance: could not parse initialChapter for", path)
        return "<p>Impossible d'extraire le contenu de ce chapitre.</p>"
    end

    -- Comme pour novel.description (cf. clean_summary) : le titre/les paragraphes
    -- peuvent contenir une référence "$id" vers une ligne texte externalisée du
    -- flux Flight au lieu du texte réel, si le chapitre est long. On les résout
    -- avant tout traitement pour éviter d'afficher ces références brutes.
    local rsc_rows = build_rsc_text_rows(html)
    if chapter.title then
        chapter.title = resolve_rsc_string(chapter.title, rsc_rows)
    end
    if chapter.paragraphs then
        for _, p in ipairs(chapter.paragraphs) do
            if p.content then
                p.content = resolve_rsc_string(p.content, rsc_rows)
            end
        end
    end

    if chapter.isPremium then
        return "<p>Ce chapitre est réservé aux membres Premium et n'est pas encore disponible gratuitement.</p>"
    end

    -- Repères "[N avis]" sur les paragraphes commentés : un seul fetch
    -- groupé par chapitre (cf. fetch_chapter_comment_counts ci-dessus)
    -- plutôt qu'un fetch par paragraphe. pcall : un souci sur cet appel ne
    -- doit jamais empêcher l'affichage du chapitre lui-même — au pire,
    -- aucun repère n'apparaît pour ce chargement.
    -- PAS d'emoji (💬) : testé sur liseuse, la police du lecteur (NotoSans,
    -- sans glyphes couleur/emoji) l'affiche en tofu/case vide — juste du
    -- texte ASCII simple, garanti de s'afficher partout.
    local comment_counts = {}
    if chapter.id then
        local ok_cc, counts = pcall(fetch_chapter_comment_counts, chapter.id)
        if ok_cc and type(counts) == "table" then
            comment_counts = counts
        end
    end

    -- `marks` : version ordonnée (même ordre que chapter.paragraphs) des
    -- SEULS paragraphes commentés, avec un aperçu tronqué du texte — sert à
    -- construire le sélecteur tap-to-open côté lecteur (ui/readerview.lua),
    -- qui ne voit normalement que le texte brut final et n'a pas accès à
    -- chapter.paragraphs. Transporté en pièce jointe JSON en fin de HTML
    -- (cf. plus bas), PAS comme attribut/balise, pour survivre au trajet
    -- Cache (fichier disque) -> ReaderView, tout en restant invisible du
    -- texte affiché une fois extrait côté lecteur.
    local marks = {}
    -- pdp (avatars) à superposer par ui/readerview.lua à côté des lignes
    -- "Auteur — date" de la section "Commentaires" de fin de chapitre
    -- construite plus bas — même mécanisme que `marks` ci-dessus, transporté
    -- lui aussi dans le trailer LNREADER_META.
    local chapter_comment_marks = {}

    local parts = {}
    if chapter.title and chapter.title ~= "" then
        -- Défensif : si le site accolait un jour ce même repère au titre,
        -- on ne veut pas non plus le laisser traîner en clair dans le H1.
        local title_text = strip_inline_avis_marker(chapter.title)
        table.insert(parts, "<h1>" .. escape_html(title_text) .. "</h1>")
    end

    if chapter.paragraphs then
        for _, p in ipairs(chapter.paragraphs) do
            -- Retire un éventuel repère "[N avis]" déjà présent dans le
            -- texte brut du paragraphe (cf. strip_inline_avis_marker
            -- ci-dessus) AVANT tout le reste, pour que ni l'affichage ni le
            -- `needle` de repérage plus bas n'en gardent la moindre trace.
            local clean_content, inline_n = strip_inline_avis_marker(p.content)
            local text = escape_html(clean_content)
            local n = comment_counts[p.id] or inline_n
            if n and n > 0 then
                -- Le texte "[N avis]" est désormais remplacé par une icône
                -- comment.png superposée au paragraphe dans readerview.lua.
                -- `needle` permet au lecteur de retrouver précisément la
                -- position du paragraphe dans le texte déjà paginé —
                -- construit à partir du texte NETTOYÉ (clean_content), pour
                -- que la recherche de position côté lecteur corresponde
                -- exactement à ce qui est réellement affiché.
                local normalized = (clean_content or ""):gsub("%s+", " ")
                local needle = utf8_prefix(normalized, 80)
                local preview = needle
                if #preview > 70 then
                    preview = utf8_prefix(needle, 70) .. "…"
                elseif #preview > 70 then
                    preview = utf8_prefix(needle, 70) .. "…"
                end
                table.insert(marks, {
                    id = p.id,
                    count = n,
                    preview = preview,
                    needle = needle,
                })
            end
            table.insert(parts, "<p>" .. text .. "</p>")

            -- Export option : insère le fil COMPLET des commentaires liés à
            -- ce paragraphe directement après celui-ci. En lecture normale,
            -- on ne fait jamais ces requêtes supplémentaires.
            if self._export_all_comments and n and n > 0 and p.id then
                local ok_pc, paragraph_comments = pcall(function()
                    local all = {}
                    local page, has_more = 1, true
                    while has_more and page <= 1000 do
                        local data = self:parseParagraphComments(chapter.id, p.id, page)
                        for _, c in ipairs((data and data.comments) or {}) do
                            all[#all + 1] = c
                        end
                        has_more = data and data.has_more or false
                        if #(data and data.comments or {}) == 0 and not has_more then break end
                        page = page + 1
                    end
                    return all
                end)
                if ok_pc and type(paragraph_comments) == "table" and #paragraph_comments > 0 then
                    table.insert(parts, "<p><strong>Commentaires du paragraphe</strong></p>")
                    for _, c in ipairs(paragraph_comments) do
                        local author_date = c.author or "Anonyme"
                        local date_str = format_chapter_comment_date(c.date)
                        if date_str then author_date = author_date .. " — " .. date_str end
                        table.insert(parts, "<p><em>" .. escape_html(author_date) .. "</em><br/>"
                            .. escape_html(c.content or "") .. "</p>")
                    end
                elseif not ok_pc then
                    logger.err("novelfrance: échec récupération commentaires paragraphe pour export", tostring(p.id), tostring(paragraph_comments))
                end
            end
        end
    elseif chapter.content then
        table.insert(parts, "<p>" .. escape_html(chapter.content) .. "</p>")
    else
        table.insert(parts, "<p>(chapitre vide)</p>")
    end

    -- Commentaires de fin de chapitre (section "Commentaires" du site, cf.
    -- ext:parseChapterComments ci-dessus) : ajoutés en TEXTE à la suite du
    -- dernier paragraphe, exactement comme le fait le site lui-même — pas
    -- besoin d'une UI dédiée (pas de fil imbriqué ni de "voir plus" : on
    -- récupère plusieurs pages d'affilée, cf. PAGE_CAP ci-dessous).
    -- pcall englobant : un souci réseau/JSON ici ne doit jamais empêcher
    -- l'affichage du chapitre lui-même (au pire, pas de section
    -- Commentaires pour ce chargement).
    if chapter.id then
        local PAGE_CAP = self._export_all_comments and 1000 or 5
        local ok_cc, chapter_comments = pcall(function()
            local all = {}
            local page, has_more = 1, true
            while has_more and page <= PAGE_CAP do
                local data = self:parseChapterComments(chapter.id, page)
                for _, c in ipairs((data and data.comments) or {}) do
                    table.insert(all, c)
                end
                has_more = data and data.has_more or false
                page = page + 1
            end
            return all
        end)
        if not ok_cc then
            logger.err("novelfrance: échec récupération des commentaires de fin de chapitre pour", chapter.id, tostring(chapter_comments))
            chapter_comments = {}
        end

        if #chapter_comments > 0 then
            table.insert(parts, "<hr/>")
            -- Espacement + ligne de séparation du titre : pas de vraie mise
            -- en forme possible ici (texte brut une fois passé par
            -- Epub.html_to_text, qui supprime TOUTES les balises), donc on
            -- simule avec une ligne vide et une ligne de tirets AU-DESSUS
            -- de "Commentaires" (déplacée depuis en-dessous, demandé).
            table.insert(parts, "<p></p>")
            table.insert(parts, "<p>――――――――――――</p>")
            table.insert(parts, "<h1>Commentaires</h1>")
            table.insert(parts, "<p></p>")
            for _, c in ipairs(chapter_comments) do
                -- Indentation réservée pour la pdp superposée par
                -- ui/readerview.lua (build_avatar_overlays), placée à
                -- GAUCHE du pseudo. Approximation : un nombre fixe
                -- d'espaces, pas un calcul pixel-exact (la taille de police
                -- de lecture est réglable par l'utilisateur après coup) —
                -- suffisant pour laisser la place à la pdp sans recouvrir
                -- le pseudo dans les tailles de police courantes.
                local has_avatar = c.avatar and c.avatar ~= ""
                -- BUG TROUVÉ : Epub.html_to_text (core/epub.lua) fait
                -- `body:gsub("[ \t]+", " ")` — TOUTE suite d'espaces/tabs
                -- normaux est réduite à UN SEUL espace. C'est pour ça
                -- qu'augmenter le nombre d'espaces classiques (10, puis 26,
                -- puis 40) n'avait STRICTEMENT AUCUN effet visible : ils
                -- finissaient tous écrasés à 1 seul espace. Fix : on réserve
                -- la place avec des espaces INSÉCABLES (U+00A0), que ce
                -- gsub ne touche pas (il ne matche que 0x20/0x09).
                local NBSP = "\194\160" -- U+00A0 en UTF-8
                local indent = has_avatar and string.rep(NBSP, 11) or ""
                local author_date = c.author or "Anonyme"
                local date_str = format_chapter_comment_date(c.date)
                if date_str then
                    author_date = author_date .. " — " .. date_str
                end
                local header_raw = indent .. author_date
                local content = escape_html(c.content or "")
                table.insert(parts, "<p><em>" .. escape_html(header_raw) .. "</em><br/>" .. content .. "</p>")

                -- Repère pour la pdp superposée par ui/readerview.lua (même
                -- mécanisme que `marks` pour les icônes de paragraphe
                -- ci-dessus). needle = "Auteur — date" SANS l'indentation :
                -- avec les espaces en tête, la position trouvée tombait sur
                -- la ligne SUIVANTE (le rendu du lecteur ne compte
                -- apparemment pas ces espaces de début de ligne dans
                -- l'intervalle de la ligne "Auteur — date", donc le repère
                -- retombait dans l'intervalle de la ligne du contenu du
                -- commentaire juste en dessous — d'où les pdp décalées d'une
                -- ligne signalées). En cherchant directement "Auteur — date"
                -- (qui, lui, est bien à l'intérieur de la ligne), le repère
                -- retombe correctement dans CETTE ligne — seule la position
                -- verticale (quelle ligne) compte pour la pdp, l'horizontale
                -- est fixée au bord gauche côté lecteur, donc peu importe
                -- que le repère pointe légèrement après le début de ligne.
                -- Pas de pdp pour un auteur sans avatar : rien à superposer.
                if has_avatar then
                    table.insert(chapter_comment_marks, { avatar = c.avatar, author = c.author, needle = author_date })
                end
            end
        end
    end

    local body_html = table.concat(parts, "\n")

    -- Trailer JSON consommé par ui/readerview.lua AVANT sa conversion en
    -- texte brut (Epub.html_to_text) — cf. commentaire plus haut : cette
    -- fonction supprime toutes les balises `<...>`, y compris un
    -- commentaire HTML `<!-- -->`, mais PAS le texte brut qu'il
    -- contiendrait. readerview.lua doit donc explicitement extraire ce
    -- bloc avant d'appeler html_to_text, sans quoi le JSON apparaîtrait
    -- tel quel dans le chapitre affiché.
    -- LIMITE CONNUE (acceptée, très improbable en prose FR) : l'extraction
    -- côté lecteur s'arrête au premier "-->" rencontré — si `preview`
    -- contenait littéralement cette séquence, le JSON serait tronqué.
    if (#marks > 0 or #chapter_comment_marks > 0) and chapter.id then
        local ok_j, JSON = pcall(require, "rapidjson")
        if not ok_j then JSON = require("json") end
        local ok_enc, encoded = pcall(JSON.encode, {
            chapterId = chapter.id,
            marks = marks,
            chapterCommentMarks = chapter_comment_marks,
        })
        if ok_enc and encoded then
            body_html = body_html .. "\n<!--LNREADER_META:" .. encoded .. "-->"
        else
            logger.err("novelfrance: échec encodage LNREADER_META pour", chapter.id)
        end
    end

    return body_html
end

-- ---------------------------------------------------------------------
-- Avis (/api/comments)
-- ---------------------------------------------------------------------
--
-- Les avis ne sont PAS dans le payload RSC de la page (contrairement à
-- initialNovel/initialChapter) : la section est en
-- BAILOUT_TO_CLIENT_SIDE_RENDERING côté React et se charge via une vraie
-- API JSON, confirmée par capture Network (2026-09-11) :
--
--   GET /api/comments?novelId=<id>&type=REVIEW&sortBy=newest&page=N&limit=10&hasRating=true
--   -> { comments: [...], total, page, limit, hasMore }
--
-- <id> est l'identifiant interne du roman (ex. "cmlwq37fc000a5eudd9xwmj3x"),
-- PAS le slug utilisé dans l'URL. On le récupère via initialNovel.id, avec
-- le même mécanisme que parseNovelMeta ci-dessus (une requête HTML de plus —
-- ce fichier ne mutualise pas les fetches entre méthodes ext, cf. parseNovel
-- qui refait aussi son propre http_get plutôt que de réutiliser
-- parseNovelMeta).
--
-- Réponse brute de /api/comments, par entrée de `comments` :
--   { content, rating (1-5), author = { username, avatar, ... },
--     reactions = { like, dislike, love, ... }, ... }
-- Contrat normalisé attendu par ui/detail.lua (build_reviews_rows) :
--   { reviews = { { author, rating, content, likes, dislikes }, ... },
--     has_more = bool }

-- Confirmé par capture Network (2026-09-11, page 2 de /api/comments) :
-- author.avatar (URL absolue Google ou chemin relatif /uploads/avatars/...,
-- ou JSON null si l'auteur n'a pas de pdp) et c.createdAt (ISO 8601).
-- as_str() est nécessaire car certaines libs JSON Lua décodent `null` en une
-- valeur sentinelle (pas un vrai nil) — sans ça, un seul avis avec avatar
-- null (ex. l'auteur "Cain" dans les avis de Shadow Slave) fait planter
-- avatar:match(...), ce qui remonte jusqu'au pcall de ext:parseReviews et
-- fait rejeter TOUTE la page d'avis (symptôme observé : "Aucun avis pour ce
-- roman" alors que l'API renvoyait pourtant des avis).
-- as_str() et resolve_avatar_url() sont maintenant définies plus haut dans
-- ce fichier (section "Commentaires par paragraphe"), et partagées avec
-- comment_to_paragraph_comment — même règles de résolution d'avatar.
local function comment_to_review(c)
    if not c then return nil end
    local author    = c.author or {}
    local reactions = c.reactions or {}

    return {
        author   = as_str(author.username) or "Anonyme",
        rating   = c.rating,
        content  = as_str(c.content) or "",
        likes    = reactions.like,
        dislikes = reactions.dislike,
        avatar   = resolve_avatar_url(author),
        date     = as_str(c.createdAt) or as_str(c.publishedAt)
            or as_str(c.date) or as_str(c.updatedAt),
    }
end

-- Tri des avis : vocabulaire générique commun à toutes les extensions (voir
-- ui/detail.lua current_api_sort()) — "newest" | "oldest" | "mostliked".
-- Seul sortBy=newest est confirmé par capture Network (2026-09-11) pour
-- cette API ; "oldest" et "mostLiked" sont des valeurs plausibles PAR
-- ANALOGIE (convention camelCase de cette même API : novelId, hasMore,
-- createdAt...) mais NON vérifiées par capture. Repli automatique sur
-- sortBy=newest (seule valeur garantie) si le candidat deviné renvoie 0 avis
-- en page 1 ou échoue — le tri demandé peut donc silencieusement ne pas être
-- honoré tant que ces deux valeurs n'auront pas été confirmées par une vraie
-- capture DevTools (même précaution que ratings_candidates de skynovels.lua).
local SORT_MAP = { newest = "newest", oldest = "oldest", mostliked = "mostLiked" }

-- Fait l'étape 2 (interroger l'API des avis) pour une valeur de sortBy
-- donnée. Factorisé pour être appelé une ou deux fois par parseReviews (tri
-- deviné, puis repli sur newest si besoin) sans dupliquer le parsing.
local function fetch_reviews_sorted(novel_id, page, sort_by)
    local url = string.format(
        "%s/api/comments?novelId=%s&type=REVIEW&sortBy=%s&page=%d&limit=10&hasRating=true",
        BASE, url_encode(novel_id), sort_by, page)
    local body, err = http_get(url)
    if not body then return nil, "HTTP: " .. tostring(err) end

    local data = json_decode(body)
    if not data or not data.comments then return nil, "JSON invalide" end

    local reviews = {}
    for idx, c in ipairs(data.comments) do
        if idx == 1 then
            -- Diagnostic confirmé le 2026-09-11 (avatar/createdAt) : log gardé
            -- au cas où l'API change de forme plus tard.
            local ok_j, JSON2 = pcall(require, "rapidjson")
            if not ok_j then JSON2 = require("json") end
            local ok_dbg, dump = pcall(JSON2.encode, c)
            logger.info("novelfrance: DEBUG premier commentaire brut =", ok_dbg and dump or "encode failed")
        end
        -- pcall : un champ inattendu sur UN avis ne doit jamais faire perdre
        -- toute la page (c'est ce qui s'est produit avec un avatar `null`
        -- avant le durcissement de comment_to_review ci-dessus).
        local ok_c, r = pcall(comment_to_review, c)
        if ok_c and r then
            table.insert(reviews, r)
        elseif not ok_c then
            logger.err("novelfrance: comment_to_review failed for", tostring(c and c.id), tostring(r))
        end
    end
    return { reviews = reviews, has_more = data.hasMore or false }
end

function ext:parseReviews(path, page, sort)
    page = page or 1

    -- Étape 1 : résoudre l'id interne du roman depuis la page HTML.
    local novel, err = fetch_json_field(BASE .. path, "initialNovel")
    if not novel or not novel.id then
        logger.err("novelfrance: parseReviews could not resolve novel id for", path, tostring(err))
        return { reviews = {}, has_more = false }
    end

    local sort_by = SORT_MAP[sort] or "newest"
    local result, err2 = fetch_reviews_sorted(novel.id, page, sort_by)
    if result and (#result.reviews > 0 or page > 1) then
        return result
    end
    if sort_by ~= "newest" then
        -- Le tri deviné n'a rien donné (forme non reconnue, erreur, ou
        -- simplement 0 avis en page 1 alors qu'il pourrait y en avoir avec
        -- le tri par défaut) : on retombe sur la seule valeur confirmée.
        logger.warn("novelfrance: parseReviews — sortBy=", sort_by, "sans résultat, repli sur newest (",
            tostring(err2 or (result and "0 avis")), ")")
        result, err2 = fetch_reviews_sorted(novel.id, page, "newest")
    end
    if not result then
        logger.err("novelfrance: parseReviews fetch failed for", path, "page", page, tostring(err2))
        return { reviews = {}, has_more = false }
    end
    if #result.reviews == 0 then
        logger.warn("novelfrance: parseReviews — 0 avis extrait pour", path, "page", page)
    end
    return result
end

return ext

--[[
POUR AFFINER popularNovels :
Tous les classements sont maintenant confirmés (most-rated, weekly, monthly,
all-time, most-bookmarked, most-discussed) sauf "Général", pour lequel je
n'ai jamais observé de requête sur le site — il est reconstruit localement
(compute_general) en moyennant la position de chaque roman dans les 4
classements ci-dessus, plutôt que d'appeler une vraie API "Général". Si tu
trouves un jour la vraie URL du site pour ce cas (Réseau DevTools → onglet
"GÉNÉRAL" → Headers → "Request URL"), envoie-la-moi et je basculerai dessus
(plus fiable et moins coûteux en requêtes qu'une reconstruction locale).
Si popularNovels renvoie 0 roman, envoie-moi le résultat — la forme du JSON
de /api/rankings/<slug> a probablement changé par rapport à ce que les
captures montraient, et ranking_item_to_novel doit être ajusté en
conséquence.

POUR AFFINER searchNovels :
Envoie-moi le HTML brut (Ctrl+U) de https://novelfrance.fr/search?q=shadow —
si /api/search/autocomplete ne fonctionne pas comme attendu, la même méthode
de capture réseau que pour la pagination des chapitres fonctionnera très
bien pour trouver le bon endpoint.
--]]