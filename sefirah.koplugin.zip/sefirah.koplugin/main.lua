-- Sefirah est un FORK de Mythos (https://github.com/unitreign/Mythos)
-- par unitreign, sous licence GPL-3.0. Modifié par thefoolwholovestheworld.
-- Sefirah is a FORK of Mythos by unitreign (GPL-3.0), modified by thefoolwholovestheworld.

-- Sefirah — point d'entrée principal du plugin.
_G.SEFIRAH_VERSION = "0.14"

local WidgetContainer = require("ui/widget/container/widgetcontainer")
local UIManager       = require("ui/uimanager")

local plugin_dir = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\][^/\\]+$") or "."
package.path = plugin_dir .. "/?.lua;"
    .. plugin_dir .. "/?/init.lua;"
    .. package.path

-- Aide à tout fermer : ferme tous les widgets Sefirah
local function close_all()
    local SefirahUI = package.loaded["ui.main_widget"]
    if SefirahUI then pcall(SefirahUI.close) end
end
_G.sefirah_close_all = close_all

local _ready = false

local function open_sefirah()
    local ok, err = pcall(function()
        local SefirahUI = require("ui.main_widget")
        local Library  = require("ui.library")
        local Browse   = require("ui.browse")
        local Detail   = require("ui.detail")
        local Sources  = require("ui.sources")
        local ExtMgr   = require("core.extmgr")

        if not _ready then
            ExtMgr.init()

            -- Câblage des générateurs de lignes des onglets
            SefirahUI.get_library_rows = function() return Library.build_rows() end
            SefirahUI.get_browse_rows  = function() return Browse.build_rows()  end
            SefirahUI.get_sources_rows = function() return Sources.build_rows() end

            -- Bibliothèque : taper sur un roman ouvre Detail au-dessus du panneau bibliothèque
            Library.on_novel_tap = function(novel)
                SefirahUI.active_tab = "library"
                Detail.on_back = nil  -- le panneau d'onglet reste actif ; fermer detail le révèle
                Detail.fetch(novel.source_id, novel.path)
            end

            -- Parcourir : taper sur un roman ouvre Detail au-dessus du panneau de parcours
            Browse.on_novel_tap = function(source_id, novel_meta)
                SefirahUI.active_tab = "browse"
                Detail.on_back = nil
                Detail.fetch(source_id, novel_meta.path or novel_meta.sourceUrl or "")
            end

            _ready = true
        end

        SefirahUI.show("library")
    end)

    if not ok then
        UIManager:show(require("ui/widget/infomessage"):new{
            text    = "Échec de l'ouverture de Sefirah :\n" .. tostring(err),
            timeout = 6,
        })
    end
end

local Sefirah = WidgetContainer:extend{
    name        = "sefirah",
    fullname    = "Sefirah",
    description = "Suivi de web novels et export EPUB",
    is_doc_only = false,
}

-- Reprise unique des réglages de lecture enregistrés sous les anciennes clés lnreader_*.
local function migrate_legacy_settings()
    if not G_reader_settings then return end
    for _, k in ipairs({ "font_face_idx", "font_size", "line_spacing", "width_idx", "night_mode" }) do
        local old_key, new_key = "lnreader_" .. k, "sefirah_" .. k
        local v = G_reader_settings:readSetting(old_key)
        if v ~= nil and G_reader_settings:readSetting(new_key) == nil then
            G_reader_settings:saveSetting(new_key, v)
            G_reader_settings:delSetting(old_key)
        end
    end
end

function Sefirah:init()
    pcall(migrate_legacy_settings)
    self.ui.menu:registerToMainMenu(self)
    local ok, Dispatcher = pcall(require, "dispatcher")
    if ok and Dispatcher then
        Dispatcher:init()
        Dispatcher:registerAction("sefirah_open", {
            category   = "none",
            event      = "SefirahOpen",
            title      = "Sefirah : Ouvrir",
            general    = true,
        })
    end
end

function Sefirah:onSefirahOpen()
    open_sefirah()
    return true
end

function Sefirah:addToMainMenu(menu_items)
    menu_items["sefirah"] = {
        text         = "Sefirah",
        sorting_hint = "tools",
        callback     = open_sefirah,
    }
end

return Sefirah
